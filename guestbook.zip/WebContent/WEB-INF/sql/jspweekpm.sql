CREATE TABLE "GUESTBOOK" (
  "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"MEMO" VARCHAR2(1000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"IP" CHAR(15 BYTE), 
	PRIMARY KEY ("IDX")
);

-- 시퀀스 값이 다시 1부터 시작하게 하려면 아래 3줄을 실행하면 된다.
delete from guestbook;
drop sequence guestbook_idx_seq;   -- 자동으로 1씩 증가하는 시퀀스를 제거한다.
create sequence guestbook_idx_seq; -- 자동으로 1씩 증가하는 시퀀스를 만든다.
-- mysql 에서 자동증가 초기화 방법 : ALTER TABLE 테이블이름 AUTO_INCREMENT = 1;

select * from guestbook;
select count(*) from guestbook;

insert into guestbook (idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '홍길동', '1111', '1등 입니다.', '192.168.2.101');
insert into guestbook (idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '임꺽정', '2222', '2등 입니다.', '192.168.2.102');
insert into guestbook (idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '장길산', '3333', '3등 입니다.', '192.168.2.103');
insert into guestbook (idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '일지매', '4444', '4등 입니다.', '192.168.2.104');

-- 디벨로퍼에서 작업한 내용은 jsp에 즉시 반영되지 않는다.
-- 디벨로퍼에서 작업한 내용을 즉시 jsp에 반영시키려면 작업 후 반드시 commit 명령을 실행해야 한다.
commit;
