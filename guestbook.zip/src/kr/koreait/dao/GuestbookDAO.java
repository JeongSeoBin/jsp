package kr.koreait.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.koreait.vo.GuestbookList;
import kr.koreait.vo.GuestbookVO;
import kr.koreait.vo.Param;

public class GuestbookDAO {
		private static GuestbookDAO instance=new GuestbookDAO();
		private GuestbookDAO() {}
	    public static GuestbookDAO getInstance() {return instance;}
	    
	    //InsertService 클래스에서 호출되어 mapper와 테이블에 저장할 데이터가 저장된 객체를 넘겨 받고
	    //guestbook.xml파일의 insert sql 명령을 실행하는 메소드
	    public void insert(SqlMapClient mapper, GuestbookVO vo) throws SQLException {
	    	System.out.println("GuestbookDAO 클래스의 insert() 메소드 실행");
	    	//insert("실행할 sql 명령의 id", [sql 명령으로 전달할 데이터])
	    	//delete() update() queryForObject() queryForList() 모두 insert()와 동일하게 사용
	    	//id는 헷갈림 방지를 위해서 메소드이름과 동일하게 사용
	    	 mapper.insert("insert", vo);
	    }
	    
	    //SelectService 클래스에서 호출되는 mapper를 넘겨 받고
	    //테이블에 저장된 전체 글의 개수를 얻어 오는 guestbook.xml파일의 select sql을 실향하는 메소드
	    public int selectCount(SqlMapClient mapper) throws SQLException {
	    	System.out.println("GuestbookDAO 클래스의 selectCount() 메소드 실행");
	    	//queryForObject() : select sql명령 실행 결과가 1 건일 경우 사용 => 리턴 타입이 Object 타입이다
	    	//queryForList() : select sql명령 실행 결과가 여러 건일 경우 사용 => 리턴 타입이 List 타입이다
	    	//queryForObject() queryForList() 메소드를 실행하고 난 후 반드시 메소드 타입으로 형변환해야 한다
	    	//mybatis에서는 queryForObject()가 selectOne()으로 queryForList()가 selectList()로 이름이 변경
	    	return (int) mapper.queryForObject("selectCount");
	    }
	    
	    //SelectService클래스에서 mapper와 startNo와 endNo가 저장된 HashMap객체를 넘겨받고
	    //테이블에 저장된 글중에서 1페이지 분량의 글을 얻어 오는 guestbook.xml파일의 select sql을 실행하는 메소드
	    public ArrayList<GuestbookVO> selectList(SqlMapClient mapper,HashMap< String, Integer> hmap) throws SQLException{
	    	return (ArrayList<GuestbookVO>) mapper.queryForList("selectList",hmap);
	    }
	    
	    //selectService클래스에서 호출되어 mapper와 수정 또는 삭제할 글 번호를 넘겨 받고
	    //테이블에 저장된 글 1건을 얻어 오는 guestbook.xml파일의 select sql 명령을 실행하는 메소드
	    public GuestbookVO selectByIdx(SqlMapClient mapper,int idx) throws SQLException {
	    	return (GuestbookVO) mapper.queryForObject("selectByIdx", idx);
	    }
	    
	    //UpdateService 클래스에서 호출되어 mapper와 수정할 글정보가 저장된 객체를 넘겨 받고
	    //테이블에서 글 1건을 수정하는 guestbook.xml 파일의 파일의 update sql 명령을 실행하는 메소드
	    public void update(SqlMapClient mapper,GuestbookVO vo) throws SQLException {
	    	mapper.update("update",vo);
	    }
	    
	    //DeleteService 클래스에서 호출되어 mapper와 삭제할 글 번호를 넘겨 받고
	    //테이블에서 글 1건을 삭제하는 guestbook.xml파일의 delete sql명령을 실행하는 메소드
	    public void delete(SqlMapClient mapper,int idx) throws SQLException {
	    	mapper.delete("delete",idx);
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper와 검색어(내용)을 넘겨 받고
	    //테이블에 저장된 전체 글 중에서 memo에 검색어를 포함하는 글의 개수를 얻어 오는 guestbook.xml파일의 select sql명령을 실행하는 메소드
	    public int selectCountMemo(SqlMapClient mapper,String item) throws SQLException {
	    	System.out.println("GuestbookDAO 클래스의 selectCountMemo() 메소드 실행");
	    	return (int) mapper.queryForObject("selectCountMemo",item);	
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper와 startNo, endNo, 검색어(내용)를 넘겨 받고 
	    //테이블에 저장된 전체 글 중에서 memo에 검색어를 포함하는 글 중에서 한 페이지 분량의 글을 얻어 오는 guestbook.xml파일의 select sql명령을 실행하는 메소드
	    public ArrayList<GuestbookVO> selectListMemo(SqlMapClient mapper,Param param) throws SQLException{
	    	System.out.println("GuestbookDAO 클래스의 selectListMemo() 메소드 실행");
	    	return (ArrayList<GuestbookVO>) mapper.queryForList("selectListMemo",param);	
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper와 검색어(이름)을 넘겨 받고 
	    //테이블에 저장된 전체 글 중에서 name에 검색어를 포함하는 글의 개수를 얻어 오는 guestbook.xml 파일의 select sql 명령을 실행하는 메소드
	    public int selectCountName(SqlMapClient mapper,String item) throws SQLException {
	    	System.out.println("GuestbookDAO 클래스의 selectCountName() 메소드 실행");
	    	return (int) mapper.queryForObject("selectCountName", item); 	
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper와 startNo, endNo, 검색어(이름)를 넘겨 받고
	    //테이블에 저장된 글 중에서 name에 검색어를 포함하는 글 중에서 한 페이지 분량의 글을 얻어 오는 guestbook.xml 파일의 select sql 명령을 실행하는 메소드
	    public ArrayList<GuestbookVO> selectListName(SqlMapClient mapper, Param param) throws SQLException{
	    	System.out.println("GuestbookDAO 클래스의 selectListName() 메소드 실행");
	    	return (ArrayList<GuestbookVO>) mapper.queryForList("selectListName", param);
	    	
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper와 startNo, endNo, 검색어(이름+내용)를 넘겨 받고
	    //테이블에 저장된 전체 글 중에서 name과 memo에 검색어를 포함하는 글의 개수를 얻어 오는 guestbook.xml 파일의 select sql 명령을 실행하는 메소드
	    public int selectCountNameMemo(SqlMapClient mapper, String item) throws SQLException{
	    	System.out.println("GuestbookDAO 클래스의 selectCountNameMemo() 메소드 실행");
	    	return (int) mapper.queryForObject("selectCountNameMemo", item); 	
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper와 startNo, endNo, 검색어(이름+내용)를 넘겨 받고
	    //테이블에 저장된 글 중에서 name과 memo에 검색어를 포함하는 글 중에서 한 페이지 분량의 글을 얻어 오는 guestbook.xml 파일의 select sql 명령을 실행하는 메소드
	    public ArrayList<GuestbookVO> selectListNameMemo(SqlMapClient mapper,Param param) throws SQLException{
	    	System.out.println("GuestbookDAO 클래스의 selectListNameMemo() 메소드 실행");
	    	return (ArrayList<GuestbookVO>) mapper.queryForList("selectListNameMemo",param);
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper,카테고리,검색어를 넘겨 받고
	    //테이블에 저장된 전체 글 중에서 카테고리에 따른 검색어를 포함하는 글의 개수를 얻어 오는 guestbook.xml 파일의 select sql 명령을 실행하는 메소드
	    public int selectCountMulti(SqlMapClient mapper,Param param) throws SQLException {
	    	System.out.println("GuestbookDAO 클래스의 selectCountMulti() 메소드 실행");
	    	return (int) mapper.queryForObject("selectCountMulti",param);	
	    }
	    
	    //SelectService 클래스에서 호출되어 mapper와 startNo, endNo, 카테고리, 검색어를 넘겨 받고
	    //테이블에 저장된 전체 글 중에서 카테고리에 따른 검색어를 포함하는 글 중에서 한 페이지 분량의 글을 얻어 오는 guestbook.xml 파일의 select sql 명령을 실행하는 메소드
	    public ArrayList<GuestbookVO> selectListMulti(SqlMapClient mapper,Param param) throws SQLException{
	    	System.out.println("GuestbookDAO 클래스의 selectCountMulti() 메소드 실행");
	    	return (ArrayList<GuestbookVO>) mapper.queryForList("selectListMulti",param);
	    	
	    }
}
