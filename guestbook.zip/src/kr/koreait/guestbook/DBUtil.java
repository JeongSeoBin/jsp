package kr.koreait.guestbook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;

public class DBUtil {
	//mysql에 연결하는 Connection을 리턴하는 메소드
	public static Connection getMysqlConnection() {
		Connection conn=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			//아래와 같이 url을 작성하면 한글을 입력하면 "?"로 보인다.
		    //String url = "jdbc:mysql://localhost:3307/weekjsp";
			//한글이 정상적으로 입력되게 하기 위해서 데이터베이스 이름 뒤에 아래의 코드를 추가한다.
			String url="jdbc:mysql://localhost:3306/weekjsp?useUnicode=true&characterEncoding=UTF-8";
			String user="root";
			String password="0000";
			conn=DriverManager.getConnection(url, user, password);
			
		}catch(ClassNotFoundException e){
			System.out.println("드라이버클래스가 없거나 로드할 수 없음<br/>");
		}catch(MySQLSyntaxErrorException e){
			System.out.println("데이터베이스가 없습니다<br/>");
		}catch(SQLException e){
			System.out.println("데이터베이스 연결정보가 옳지 않습니다<br/>");
		}catch(Exception e){
			System.out.println("오류발생<br/>");
		}
		return conn;		
	}
	
	//데이터베이스 작업에 사용한 객체를 닫는 메서드
//  데이터베이스 연결에 사용한 객체를 닫는 메서드
	public static void close(Connection conn) {
		if(conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
	}
//	데이터베이스와 연결한 후 sql 명령을 실행하는 메소드 => 간단한 sql 명령, 정적 sql 명령 실행
	public static void close(Statement stmt) {
		if(stmt != null) { try { stmt.close(); } catch (SQLException e) { e.printStackTrace(); } }
	}
//	데이터베이스와 연결한 후 sql 명령을 실행하는 메소드 => 복잡한 sql 명령, 동적 sql 명령 실행
	public static void close(PreparedStatement pstmt) {
		if(pstmt != null) { try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); } }
	}
//  select sql명령을 실행한 결과를 기억하는 객체를 닫는 메소드
	public static void close(ResultSet rs) {
		if(rs != null) { try { rs.close(); } catch (SQLException e) { e.printStackTrace(); } }
	}

//oracle에 연결하는 Connection을 리턴하는 메소드
	public static Connection getOracleConnection(){
		Connection conn=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String user="koreait";
			String password="0000";
			conn=DriverManager.getConnection(url, user, password);
			
			System.out.println("연결 성공"+conn);
			
		}catch(ClassNotFoundException e) {
			System.out.println("드라이버 클래스가 없습니다");	
		}catch(SQLException e) {
			System.out.println("데이터 베이스 연결 정보가 없습니다");	
		}
		return conn;	
	}
}
