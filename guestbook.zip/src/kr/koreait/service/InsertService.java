package kr.koreait.service;

import java.sql.SQLException;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.koreait.dao.GuestbookDAO;
import kr.koreait.ibatis.MyAppSqlConfig;
import kr.koreait.vo.GuestbookVO;

//InsertService클래스는 insert sql 명령이 실행되기 전에 실행해야할 작업이 있으면 실행하는 클래스 
public class InsertService {
	//sigleton 패턴은 프로그램에서 한 순간에 단 1개의 객체만 필요할 경우 만들어 사용하는 방법
	//sigleton 패턴 코딩 방법
	//1. 자기 자신의 객체를 기본생성자를 사용해서 정적 멤버로 선언
	private static InsertService instance=new InsertService();
	//2. 클래스 외부에서 객체를 생성할 수 없도록 기본 생성자의 접근권한을 private로 변경
	private InsertService() {};
	//3. 자기 자신의 객체를 리턴하는 정적 메소드를 만든다
	public static InsertService getInstance() {return instance;}
	
	//insertOK.jsp에서 넘어오는 테이블에 저장할 데이터가 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//DAO클래스에서 sql 명령을 실행하는 메소드를 실행하기 전에 필요한 작업이 있으면 실행하는 메소드
	public void insert(GuestbookVO vo) {
		System.out.println(vo);
		System.out.println("InsertService 클래스의 insert() 메소드 실행");
		
		//mapper를 얻어온다
		//mapper에는 데이터베이스와 연결하는 Connection과 데이터베이스에 연결한 후 실행할 sql명령이 저장
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		
		//DAO클래스에서 sql 명령을 실행하는 메소드를 실행하기전에 필요한 작업이 있으면 실행
		
		//실제 insert sql명령을 실행하는 DAO클래스의 메소드를 호출
		try {
			GuestbookDAO.getInstance().insert(mapper, vo);
		}catch(SQLException e) {
			e.printStackTrace();
		}	
	}
}
