package kr.koreait.service;

import java.sql.SQLException;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.koreait.dao.GuestbookDAO;
import kr.koreait.ibatis.MyAppSqlConfig;
import kr.koreait.vo.GuestbookVO;

public class UpdateService {
	private static UpdateService instance=new UpdateService();
	private UpdateService() {}
	public static UpdateService getInstance() {return instance;}
	
	//updateOK.jsp에서 호출되어 수정할 글 정보가 저장된 객체를 넘겨 받고 mapper를 얻어 온 후
	//GuestbookDAO 클래스의 글 1건을 수정하는 메소드를 호출하는 메소드
	public void update(GuestbookVO vo) {
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		try {
			GuestbookDAO.getInstance().update(mapper, vo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
