package kr.koreait.service;

import java.sql.SQLException;
import java.util.HashMap;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.koreait.dao.GuestbookDAO;
import kr.koreait.ibatis.MyAppSqlConfig;
import kr.koreait.vo.GuestbookList;
import kr.koreait.vo.GuestbookVO;
import kr.koreait.vo.Param;

public class SelectService {
	private static SelectService instance=new SelectService();
	private SelectService() {}
	public static SelectService getInstance() {return instance;}
	
	/* * * list.jsp에서 화면에 표시할 페이지 번호를 넘겨 받고 mapper를 얻어 온 후
	sql을 실행하기전 필요한 전처리를 하고 GuestDAO클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호츨하는 메소드 * * */
	public GuestbookList selectList(int currentPage) {
		System.out.println("SelectService 클래스의 selectList() 메소드 실행");
		
		/* * mapper를 얻어 옴 * */
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		
		/* * sql 실행 전 전처리
		GuestDAO클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호츨하기 위해 startNo와 endNo에 대한 작업실행 * */
		GuestbookList guestbookList=null;//1페이지 분량의 글과 페이지 작업에 사용할 8개의 변수를 저장해서 리턴시킬 객체를 선언
		GuestbookDAO dao=GuestbookDAO.getInstance();
		
		try {
			/* 변수 초기화 */
			int pageSize=10;//1페이지에 표시할 글의 개수를 정한다
			int totalCount=dao.selectCount(mapper);//테이블에 저장된 전체 글의 개수를 얻어 온다
			//System.out.println(totalCount);	
			
			//pageSize,totalCount,currentPage를 GuestbookList클래스 생성자로 넘겨서
			//1 페이지 분량의 글과 페이지 작업에 사용할 8개 변수를 초기화시키는 클래스의 객체를 생성
			guestbookList=new GuestbookList(pageSize, totalCount, currentPage);//8개의 변수가 계산된다
			
			/* hashMap 생성 */
			//mysql을 사용할때는 startNo와 pageSize를 이용해 limit를 사용해서 1페이지 분랭의 글을 얻어 왔지만
			//오라클은 limit가 없기 때문에 startNo와 endNo를 sql명령으로 넘겨서 startNo와 endNo사이의 글 목록을 얻어 와야 한다
			//xml파일의 parameterClass에는 1개의 자료형만 쓸 수 있기 때문에 하나의 객체로 만든다
			//startNo와 endNo는 모두 int 타입이므로 HashMap객체를 만들어서 startNo와 endNo를 저장시켜 xml파일로 넘겨 준다
			HashMap<String, Integer> hmap=new HashMap<>();
			hmap.put("startNo", guestbookList.getStartNo());
			hmap.put("endNo", guestbookList.getEndNo());
			
			/* * GuestDAO클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호츨 * */
			guestbookList.setGuestbookList(dao.selectList(mapper, hmap));//1페이지 분량의 글을 얻어와서 GuestbookList클래스 객체의 ArrayList에 저장
			System.out.println(guestbookList);
			
		}catch(SQLException e) {e.printStackTrace();}
		
		return guestbookList;
	}
	
	//selectByIdx.jsp에서 호출되는 수정 또는 삭제할 글 번호를 넘겨 받고 mapper를 얻어 온 후
	//GuestbookDAO 클래스의 글 1건을 얻어 오는 메소드를 호출하는 메소드
	public GuestbookVO selectByIdx(int idx) {
		GuestbookVO vo=null;//얻어온 글 1건을 저장해서 리턴 시킬 객체 선언
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		try {
			vo=GuestbookDAO.getInstance().selectByIdx(mapper, idx);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;
	}
	
	/* * * list.jsp에서 호출되어 화면에 표시할 페이지 번호와 검색어(내용)를 넘겨 받고 mapper를 얻어온 후
	sql을 실행하기전 필요한 전처리를 하고 GuestbookDao클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호출하는 메소드* * */
	public GuestbookList selectListMemo(int currentPage, String item) {
		System.out.println("SelectService 클래스의 selectListMemo() 메소드 실행");
		
		/* * mapper를 얻어 옴 * */
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		
		/* * sql 실행 전 전처리
		GuestDAO 클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호츨하기 위해 startNo, endNo, item에 대한 작업실행* */
		GuestbookList guestbookList=null;
		try {
			/* 변수 초기화 */
			int pageSize=10;
			//테이블에 저장된 전체 글 중에서 memo에 검색어를 포함한 글의 개수를 얻어 온다
			int totalCount=GuestbookDAO.getInstance().selectCountMemo(mapper, item);
			guestbookList=new GuestbookList(pageSize, totalCount, currentPage);
			
			/* Param 클래스 생성 */
			//startNo,endNo와 item은 자료형이 다르기 때문에 HashMap객체를 사용할 수 없고 별도의 클래스(Param)를 만들어 처리한다
			Param param=new Param();
			param.setStartNo(guestbookList.getStartNo());
			param.setEndNo(guestbookList.getEndNo());
			param.setItem(item);
			
			/* * GuestDAO클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호츨 * */
			//memo필드에 검색어를 포함하는 한 페이지 분량의 글을 얻어 온다
			guestbookList.setGuestbookList(GuestbookDAO.getInstance().selectListMemo(mapper, param));
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return guestbookList;	
	}
	
	//list.jsp에서 호출되어 화면에 표시할 페이지 번호와 검색어(이름)을 넘겨 받고 mapper를 얻어 온 후
	//sql 명령을 실행하기 전에 필요한 전처리를 하고 GuestbookDAO 클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호출하는 메소드
	public GuestbookList selectListName(int currentPage,String item) {
		System.out.println("SelectService 클래스의 selectListName() 메소드 실행");
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		GuestbookList guestbookList=null;
		
		try {
		int pageSize=10;
		//테이블에 저장된 글 중에서 name에 검색어를 포함한 글의 개수를 얻어 온다
		int totalCount=GuestbookDAO.getInstance().selectCountName(mapper, item);
		guestbookList=new GuestbookList(pageSize, totalCount, currentPage);
		
		Param param=new Param();
		param.setStartNo(guestbookList.getStartNo());
		param.setEndNo(guestbookList.getEndNo());
		param.setItem(item);
		
		guestbookList.setGuestbookList(GuestbookDAO.getInstance().selectListName(mapper, param));
		}catch (SQLException e) {}
	
		return guestbookList;
	}
	
	//list.jsp에서 호출되어 화면에 표시할 페이지 번호와 검색어(이름+내용)를 넘겨 받고 mapper를 얻어 온 후
	//sql 명령을 실행하기 전에 필요한 전처리를 하고 GuestbookDAO 클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호출하는 메소드
	public GuestbookList selectListNameMemo(int currentPage, String item) {
		System.out.println("SelectService 클래스의 selectListNameMemo() 메소드 실행");
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		GuestbookList guestbookList=null;
		
		try {
		int pageSize=10;
		//테이블에 저장된 글 중에서 name과 memo에 검색어를 포함한 글의 개수를 얻어 온다
		int totalCount=GuestbookDAO.getInstance().selectCountNameMemo(mapper, item);
		guestbookList=new GuestbookList(pageSize, totalCount, currentPage);
		
		Param param=new Param();
		param.setStartNo(guestbookList.getStartNo());
		param.setEndNo(guestbookList.getEndNo());
		param.setItem(item);
		
		guestbookList.setGuestbookList(GuestbookDAO.getInstance().selectListNameMemo(mapper, param));
		}catch (SQLException e) {}
		
		return guestbookList;	
	}
	
	//list.jsp에서 호출되어 화면에 표시할 페이지 번호, 카테고리, 검색어를 넘겨 받고 mapper를 얻어 온 후
	//GuesubookDAO 클래스의 한 페이지 분량의 글을 얻어 오는 메소드를 호출하는 메소드
	public GuestbookList selectListMulti(int currentPage, String category, String item) {
		System.out.println("SelectService 클래스의 selectListMulti() 메소드 실행");
		SqlMapClient mapper=MyAppSqlConfig.getSqlMapInstance();
		GuestbookList guestbookList=null;
		
		try {
		int pageSize=10;
		
		//테이블에 저장된 전체 글 중에서 카테고리에 따른 검색어를 포함한 글의 개수를 얻어 온다
		Param param=new Param();
		param.setCategory(category);
		param.setItem(item);
		int totalCount=GuestbookDAO.getInstance().selectCountMulti(mapper, param);
		
		guestbookList=new GuestbookList(pageSize, totalCount, currentPage);
		
		param.setStartNo(guestbookList.getStartNo());
		param.setEndNo(guestbookList.getEndNo());
		
		guestbookList.setGuestbookList(GuestbookDAO.getInstance().selectListMulti(mapper, param));
		}catch (SQLException e) {}
		
		return guestbookList;
	}
}
