<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="kr.koreait.memoList.DBUtil"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style type="text/css">

	span { background-color: black; color: white; }
	a:link { color: black; text-decoration: none; }
	a:visited { color: black; text-decoration: none; }
	a:hover { color: red; text-decoration: none; }
	a:active { color: blue; text-decoration: none; }
</style>
</head>
<body>
<!-- 입력화면 설계 -->
<form action="memoInsert.jsp" method="post">
<table width="800" align="center" border="1" cellpadding="5" cellspacing="0">
<tr><th colspan="3">출첵 게시판</th></tr>
<tr>
<td width="80" align="center">이름</td>
<td width="80" align="center">비밀번호</td>
<td width="640" align="center">메모</td>
</tr>
<tr>
<td>
<input type="text" name="name" size="7"/>
</td>
<td>
<input type="text" name="password" size="7"/>
</td>
<td>
<input type="text" name="memo" size="70"/>
<input type="submit" value="저장"/>
</td>
</tr>
</table>
</form>
<!--입력화면 설계 끝 -->

<hr size="3" color="black"/>

<%
//페이지 작업에 사용할 8개의 변수를 선언 => 계산에 의한 값을 가져야 하는 변수는 0으로 초기화
int pageSize=10;//한 페이지에 표시할 글의 개수
int totalCount=0;//테이블에 저장된 전체 글의 개수
int totalPage=0;//전체 페이지의 개수
int currentPage=1;//현재 브라우저에 표시되는 페이지 번호
int startNo=0;//현재 브라우저에 표시되는 페이지 시작글의 인덱스번호
int endNo=0;//현재 브라우저에 표시되는 페이지의 마지막글의 인덱스번호(오라클에서 사용)
int startPage=0;//페이지 이동 하이퍼링크나 버튼의 시작 페이지 번호
int endPage=0;//페이지 이동 하이퍼링크나 버튼의 마지막 페이지 번호

Connection conn=DBUtil.getMysqlConnection();

//==========================================================================================

//totalCount에 테이블에 저장된 전체 글의 개수를 얻어와 저장시킨다
String sql="select count(*) from memo";
PreparedStatement pstmt=conn.prepareStatement(sql);
ResultSet rs=pstmt.executeQuery();
rs.next();//테이블에 저장된 글이 있으면 글의 개수를 얻어 올 것이고 저장된 글이 없으면 0을 얻어 올 것이므로 if를 사용해서 비교할 필요없다
totalCount=rs.getInt(1);//필드이름이 없을때 열번호 이용

//totalPage에 전체 페이지 개수를 계산해서 저장한다
totalPage=(totalCount-1)/pageSize + 1;

//==========================================================================================

//이전 페이지에서 넘어오는 화면에 표시할 페이지 번호를 받는다
//게시판이 최초로 실행되거나 memoInsert.jsp에서 호출될때 넘어오는 currentPage가 없으므로 null
//정상적으로 currentPage가 넘어오면 숫자로 바꿔서 저장할 수 있지만 null이면 NumberFormatException이 발생되어 예외처리
try{
	currentPage=Integer.parseInt(request.getParameter("currentPage"));
	//현재 화면에 표시할 페이지번호는 전체페이지 개수보다 클 수 없으므로
	//화면에 표시할 페이지번호가 전체페이지의 개수보다 큰 값이 넘어올 경우 전체페이지 개수로 수정
	currentPage=currentPage>totalPage?totalPage:currentPage;
}catch(NumberFormatException e){
	//예외가 발생되면 아무런일도 하지 않는다
	//currentPage초기치가 1이기 때문에 예외가 발생하면 1페이지의 내용이 표시
}

//==========================================================================================

//브라우저에 출력할 한 페이지 분량의 글을 얻어 오기 위해서 페이지에 표시될 시작글의 인덱스번호를 계산
//select명령 실행결과 맨 처음 나오는 인덱스 값은 mysql은 0이고 oracle은 1이다
startNo=(currentPage-1)*pageSize;

//mysql은 limit를 사용하기 때문에 endNo변수를 계산할 필요없지만 오라클은 limit가 없기 때문에 endNo변수를 계산해야 함
endNo=startNo+pageSize-1;
//마지막 페이지에 표시될 글의 개수는 반드시 화면에 표시할 개수만큼 표시되지 않는다
//한 페이지에 표시할 마지막글의 인덱스번호가 전체 글의 개수보다 커지면 안되기 때문에 
//마지막글의 인덱스번호가 전체글의 개수보다 커지면 전체 글의 개수로 마지막 글의 인덱스번호를 수정
endNo=(endNo>totalCount)?totalCount:endNo;

//==========================================================================================

//브라우저에 표시할 한 페이지분량의 글을 startNo와 limit를 이용해서 얻어 온다
sql="select * from memo order by idx desc limit ?,?";
pstmt=conn.prepareStatement(sql);
pstmt.setInt(1,startNo);
pstmt.setInt(2, pageSize);
rs=pstmt.executeQuery();

//==========================================================================================

%>
<table width="1000" align="center" border="1" cellspacing="0" cellpadding="5">
<tr>
<td width="80" align="center">글번호</td>
<td width="80" align="center">이름</td>
<td width="640" align="center">메모</td>
<td width="100" align="center">작성일</td>
<td width="100" align="center">ip</td>
</tr>
<tr>
<td colspan="5" align="right"><%=totalCount%>개(<%=currentPage%>/<%=totalPage%>page)</td>
</tr>
<%
if(rs.next()){
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy.MM.dd(E)");
do{
%>
<tr>
<td><%=rs.getInt("idx")%></td>
<td><%=rs.getString("name") %></td>
<td><%=rs.getString("memo") %></td>
<td><%=sdf.format(rs.getTimestamp("WriteDate"))%></td>
<td><%=rs.getString("ip") %></td>
</tr>
<%
}while(rs.next());
}else{
%>
	<tr><td colspan="5"><marquee>테이블에 저장된 글이 없습니다</marquee></td></tr>
<% 
}
%>
<!--1페이지부터 마지막페이지까지 이동할 수 있는 하이퍼링크 또는 버튼을 만든다 -->
<tr>
<td colspan="5" align="center">
<%
for(int i=1;i<=totalPage;i++){
	if(currentPage == i){
%>
		<%-- <span>[<%=i%>]</span> --%>
		<%-- <input type="button" value="<%=i%>" disabled="disabled"><!--disabled="disabled 버튼 비활성화--> --%>
		<button disabled="disabled"><%=i%></button>
<%
	}else{
%>
		<%-- <a href="?currentPage=<%=i%>">[<%=i%>]</a> --%>
		<%-- <input type="button" value="<%=i%>" onclick="location.href='?currentPage=<%=i%>'"> --%>
		<button onclick="location.href='?currentPage=<%=i%>'"><%=i%></button>
<%		
	}
}
%>
</td>
</tr>

<tr>
<td colspan="5" align="center">
<%
for(int i=1;i<=totalPage;i++){
	if(currentPage == i){
		/* out.println("<span>[" + i + "]</span>"); */
		out.println("<input type='button' value='" + i + "'disabled='disabled'>");	
	}else{
		/* out.println("<a href='?currentPage=" + i + "'>[" + i + "]</a>"); */
		out.println("<input type='button' value='"+ i + "' onclick='location.href=\"?currentPage="+ i +"\"'>");
		//out.println("")에 그대로 복사하고 
		//큰 따옴표를 작은 따옴표를 바꾸고 작은 따옴표는 \"로 바꾸고 html과 jsp를 "html"+ jsp +"html"로 연결	
	}
}
%>
</td>
</tr>
</table>
</body>
</html>