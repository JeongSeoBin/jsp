<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="kr.koreait.memoList.DBUtil"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<!-- 입력화면 설계 -->
<form action="memoInsert.jsp" method="post">
<table width="800" align="center" border="1" cellpadding="5" cellspacing="0">
<tr><th colspan="3">출첵 게시판</th></tr>
<tr>
<td width="80" align="center">이름</td>
<td width="80" align="center">비밀번호</td>
<td width="640" align="center">메모</td>
</tr>
<tr>
<td>
<input type="text" name="name" size="7"/>
</td>
<td>
<input type="text" name="password" size="7"/>
</td>
<td>
<input type="text" name="memo" size="70"/>
<input type="submit" value="저장"/>
</td>
</tr>
</table>
</form>
<!--입력화면 설계 끝 -->

<hr size="3" color="black"/>

<%
//테이블에 저장된 글목록 전체를 글번호(idx)의 내림차순으로(최신글 부터) 얻어 온다
Connection conn=DBUtil.getMysqlConnection();
String sql="select * from memo order by idx desc";
PreparedStatement pstmt=conn.prepareStatement(sql);
ResultSet rs=pstmt.executeQuery();//select결과를 변수로 받아 놓음

/* //ResultSet객체에 다음 데이터가 없을때까지 반복하며 글을 출력
//next() : ResultSet 객체에 저장된 다음 데이터로 접근 -> 다음 데이터가 있으면 true 없으면 false를 리턴
if(rs.next()){
	//테이블에 글이 있는 경우
	do{
		out.println(rs.getInt("idx")+",");
		out.println(rs.getString("name") + ",");
		out.println(rs.getString("password") + ",");
		out.println(rs.getString("memo") + ",");
		out.println(rs.getString("ip") + ",");
		out.println("<br/>");	
	}while(rs.next());
}else{
	//테이블에 글이 없는 경우
	out.println("테이블에 저장된 글이 없습니다");
} */
%>

<table width="1000" align="center" border="1" cellspacing="0" cellpadding="5">
<tr>
<td width="80" align="center">글번호</td>
<td width="80" align="center">이름</td>
<td width="640" align="center">메모</td>
<td width="100" align="center">작성일</td>
<td width="100" align="center">ip</td>
</tr>
<!--반복문의 조건을 만족하지 않을때 무언가를 실행하고 싶을때-->
<%
if(rs.next()){
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy.MM.dd(E)");
do{
%>
<tr>
<td><%=rs.getInt("idx")%></td>
<td><%=rs.getString("name") %></td>
<td><%=rs.getString("memo") %></td>
<td><%=sdf.format(rs.getTimestamp("WriteDate"))%></td>
<td><%=rs.getString("ip") %></td>
</tr>
<%
}while(rs.next());
}else{
%>
	<tr><td colspan="5"><marquee>테이블에 저장된 글이 없습니다</marquee></td></tr>
<% 
}
%>
</table>
</body>
</html>