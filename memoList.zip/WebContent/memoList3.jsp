<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="kr.koreait.memoList.DBUtil"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style type="text/css">
	span { background-color: black; color: white; }
	a:link { color: black; text-decoration: none; }
	a:visited { color: black; text-decoration: none; }
	a:hover { color: red; text-decoration: none; }
	a:active { color: blue; text-decoration: none; }
	
  /*https://www.w3schools.com*/	
</style>
</head>
<body>
<!-- 입력화면 설계 -->
<form action="memoInsert.jsp" method="post">
<table width="800" align="center" border="1" cellpadding="5" cellspacing="0">
<tr><th colspan="3">출첵 게시판</th></tr>
<tr>
<td width="80" align="center">이름</td>
<td width="80" align="center">비밀번호</td>
<td width="640" align="center">메모</td>
</tr>
<tr>
<td>
<input type="text" name="name" size="7"/>
</td>
<td>
<input type="text" name="password" size="7"/>
</td>
<td>
<input type="text" name="memo" size="70"/>
<input type="submit" value="저장"/>
</td>
</tr>
</table>
</form>
<!--입력화면 설계 끝 -->

<hr size="3" color="black"/>

<%
int pageSize=10;
int totalCount=0;
int totalPage=0;
int currentPage=1;
int startNo=0;
int endNo=0;
int startPage=0;//페이지 이동 하이퍼링크나 버튼의 시작 페이지 번호
int endPage=0;//페이지 이동 하이퍼링크나 버튼의 마지막 페이지 번호

Connection conn=DBUtil.getMysqlConnection();

//==========================================================================================

String sql="select count(*) from memo";
PreparedStatement pstmt=conn.prepareStatement(sql);
ResultSet rs=pstmt.executeQuery();
rs.next();
totalCount=rs.getInt(1);

totalPage=(totalCount-1)/pageSize + 1;

//==========================================================================================

try{
	currentPage=Integer.parseInt(request.getParameter("currentPage"));
	currentPage=currentPage>totalPage?totalPage:currentPage;
}catch(NumberFormatException e){}

//==========================================================================================

startNo=(currentPage-1)*pageSize;

endNo=startNo+pageSize-1;
endNo=(endNo>totalCount)?totalCount:endNo;

//==========================================================================================

sql="select * from memo order by idx desc limit ?,?";
pstmt=conn.prepareStatement(sql);
pstmt.setInt(1,startNo);
pstmt.setInt(2, pageSize);
rs=pstmt.executeQuery();

//==========================================================================================

%>
<table width="1000" align="center" border="1" cellspacing="0" cellpadding="5">
<tr>
<td width="80" align="center">글번호</td>
<td width="80" align="center">이름</td>
<td width="640" align="center">메모</td>
<td width="100" align="center">작성일</td>
<td width="100" align="center">ip</td>
</tr>
<tr>
<td colspan="5" align="right"><%=totalCount%>개(<%=currentPage%>/<%=totalPage%>page)</td>
</tr>
<%
if(rs.next()){
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy.MM.dd(E)");
do{
%>
<tr>
<td><%=rs.getInt("idx")%></td>
<td><%=rs.getString("name") %></td>
<td><%=rs.getString("memo") %></td>
<td><%=sdf.format(rs.getTimestamp("WriteDate"))%></td>
<td><%=rs.getString("ip") %></td>
</tr>
<%
}while(rs.next());
}else{
%>
	<tr><td colspan="5"><marquee>테이블에 저장된 글이 없습니다</marquee></td></tr>
<% 
}
%>

<tr>
<td colspan="5" align="center">
<%
//페이지 이동 하이퍼링크나 버튼의 시작 페이지 번호와 마지막 페이지 번호를 계산한다
startPage=(currentPage-1)/10*10+1;
endPage=startPage+9;
//페이지 이동 하이퍼링크 또는 버튼의 마지막 페이지 번호가 전체 페이지 수보다 커지면
//존재하지 않는 페이지 번호가 표시되기 때문에 마지막 페이지 번호를 전체 페이지 수로 변경
endPage=endPage>totalPage?totalPage:endPage;

//===============================================================================================

//이전 10페이지로 이동하는 버튼과 처음으로 이동하는 버튼 추가
//startPage가 1보다 크면 이전 10페이지가 있다
if(startPage>1){
%>
	<input type="button" value="start page" onclick="location.href='?currentPage=1'"/>
	<input type="button" value="-10 page" onclick="location.href='?currentPage=<%=startPage-1%>'"/>
<%	
}else{
%>
	<input type="button" value="start page" disabled="disabled" title="이미 첫 페이지 입니다"/>
	<input type="button" value="-10 page" disabled="disabled" title="이전 10 페이지가 없습니다"/>
<%
}

//이전 페이지로 이동하는 버튼 추가
//currentPage가 1보다 크면 이전 페이지가 있다
if(currentPage>1){
%>
	<input type="button" value="-1 page" onclick="location.href='?currentPage=<%=currentPage-1%>'"/>
<%
}else{
%>
	<input type="button" value="-1 page" disabled="disabled" title="이전 페이지가 없습니다"/>
<%
}

//===============================================================================================

//10페이지 단위로 이동하는 하이퍼링크 또는 버튼을 출력
for(int i=startPage;i<=endPage;i++){
	if(currentPage == i){
%>
        <%-- <span>[<%=i%>]</span> --%>
		<input type="button" value="<%=i%>" disabled="disabled">
<%
	}else{
%>
		<%-- <a href="?currentPage=<%=i%>">[<%=i%>]</a> --%>
		<input type="button" value="<%=i%>" onclick="location.href='?currentPage=<%=i%>'">
<%		
	}
}

//===============================================================================================

//다음 페이지로 이동하는 버튼 추가
//currentPage가 totalPage보다 작으며 다음 페이지가 있다
if(currentPage<totalPage){
%>
	<input type="button" value="+1 page" onclick="location.href='?currentPage=<%=currentPage+1%>'"/>
<%
}else{
%>
	<input type="button" value="+1 page" disabled="disabled" title="다음 페이지가 없습니다"/>
<%
}

//다음 10페이지로 이동하는 버튼과 마지막 페이지로 이동하는 버튼 추가
//endPage가 totalPage보다 작으면 다음 10페이지가 있다
if(endPage<totalPage){
%>
	<input type="button" value="+10 page" onclick="location.href='?currentPage=<%=endPage+1%>'"/>
	<input type="button" value="end page" onclick="location.href='?currentPage=<%=totalPage%>'"/>
<%	
}else{
%>
	<input type="button" value="+10 page" disabled="disabled" title="다음 10 페이지가 없습니다"/>
	<input type="button" value="end page" disabled="disabled" title="이미 마지막 페이지 입니다"/>
<%
}
%>
</td>
</tr>
</table>
</body>
</html>