<%@page import="kr.koreait.memoList.DBUtil"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
//데이터베이스와 연결에 사용할 객체를 자바파일에서 가져온다
Connection conn=DBUtil.getMysqlConnection();
out.println("데이터베이스에 연결성공" + conn + "<br/>");
DBUtil.close(conn);
%>

</body>
</html>