<%@page import="java.sql.SQLException"%>
<%@page import="com.mysql.jdbc.SQLError"%>
<%@page import="com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
//데이터베이스와 연결에 사용할 객체를 선언
Connection conn=null;

try{
	//mysql드라이버 클래스를 읽어 들임
	Class.forName("com.mysql.jdbc.Driver");
	
	//mysql에 연결
	String url="jdbc.mysql://localhost:3306/weekjsp";
	String user="root";
	String password="0000";
	conn=DriverManager.getConnection(url,user,password);
	
	out.println("연결성공"+conn+"<br/>");//매번 바뀌는 부분은 여기뿐
	
}catch(ClassNotFoundException e){
	out.println("드라이버클래스가 없거나 로드할 수 없음<br/>");
}catch(MySQLSyntaxErrorException e){
	out.println("데이터베이스가 없습니다<br/>");
}catch(SQLException e){
	out.println("데이터베이스 연결정보가 옳지 않습니다<br/>");
}catch(Exception e){
	out.println("오류발생<br/>");
}finally{
	//데이터베이스와의 연결을 닫는다
	if(conn != null){//만약 conn이 null이면 중간에 예외발생한거라 닫을 필요없음
		conn.close();
	}
}
%>

</body>
</html>