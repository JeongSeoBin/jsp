<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="kr.koreait.memoList.DBUtil"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style type="text/css">
	span { background-color: black; color: white; }
	a:link { color: black; text-decoration: none; }
	a:visited { color: black; text-decoration: none; }
	a:hover { color: red; text-decoration: none; }
	a:active { color: blue; text-decoration: none; }
	
  /*https://www.w3schools.com*/	
</style>
</head>
<body>
<!-- 입력화면 설계 -->
<form action="memoInsert.jsp" method="post">
<table width="800" align="center" border="1" cellpadding="5" cellspacing="0">
<tr><th colspan="3">출첵 게시판</th></tr>
<tr>
<td width="80" align="center">이름</td>
<td width="80" align="center">비밀번호</td>
<td width="640" align="center">메모</td>
</tr>
<tr>
<td>
<input type="text" name="name" size="7"/>
</td>
<td>
<input type="text" name="password" size="7"/>
</td>
<td>
<input type="text" name="memo" size="70"/>
<input type="submit" value="저장"/>
</td>
</tr>
</table>
</form>
<!--입력화면 설계 끝 -->

<hr size="3" color="black"/>

<%
int pageSize=10;
int totalCount=0;
int totalPage=0;
int currentPage=1;
int startNo=0;
int endNo=0;
int startPage=0;
int endPage=0;

//콤보상자에서 선택한 화면에 표시할 글의 개수를 받는다
//게시판이 최초로 실행될때 이전 페이지가 없으므로 넘어오는 pageSize가 null이기 때문에 예외처리해야 한다
try{
	pageSize=Integer.parseInt(request.getParameter("pageSize"));
	//페이지 이동 버튼을 클릭하여 페이지를 이동했을때도 선택한 pageSize를 유지할려면 pageSize를 session에 저장해야 한다
	//화면에 표시할 글의 개수가 정상적으로 넘어왔으므로 session에 저장
	session.setAttribute("pageSize", pageSize + "");
}catch(NumberFormatException e){
	//이전 페이지에서 넘어오는 pageSize가 없으면 session에 저정된 pageSize를 얻어와서 화면에 표시할 글의 개수를 지정
	//브라우저가 최초로 실행될때 session이 만들어지기 때문에
	//브라우저가 실행되면 이번 페이지에서 넘어오는 pageSize노 null이고 session에 저장된 pageSize도 null
	String temp=(String)session.getAttribute("pageSize");
	if(temp != null){
		pageSize=Integer.parseInt(temp);
	}
	//브라우저가 최초로 실행될때는 pageize도 null이고 session에 저장된 pageSize도 null이므로 pageSize 초기값인 10으로 지정
}

Connection conn=DBUtil.getMysqlConnection();

//==========================================================================================

String sql="select count(*) from memo";
PreparedStatement pstmt=conn.prepareStatement(sql);
ResultSet rs=pstmt.executeQuery();
rs.next();
totalCount=rs.getInt(1);

totalPage=(totalCount-1)/pageSize + 1;

//==========================================================================================

try{
	currentPage=Integer.parseInt(request.getParameter("currentPage"));
	currentPage=currentPage>totalPage?totalPage:currentPage;
}catch(NumberFormatException e){}

//==========================================================================================

startNo=(currentPage-1)*pageSize;

endNo=startNo+pageSize-1;
endNo=(endNo>totalCount)?totalCount:endNo;

//==========================================================================================

sql="select * from memo order by idx desc limit ?,?";
pstmt=conn.prepareStatement(sql);
pstmt.setInt(1,startNo);
pstmt.setInt(2, pageSize);
rs=pstmt.executeQuery();

//==========================================================================================

%>
<table width="1100" align="center" border="1" cellspacing="0" cellpadding="5">
<tr>
<td width="80" align="center">글번호</td>
<td width="80" align="center">이름</td>
<td width="640" align="center">메모</td>
<td width="100" align="center">작성일</td>
<td width="100" align="center">ip</td>
<td width="100" align="center">&nbsp;</td>
</tr>

<tr>
<td colspan="3">
<form action="?" method="post">
<select name="pageSize">
<option>페이지당 표시할 글의 개수를 선택하시오</option>
<option>3</option>
<option>5</option>
<option>10</option>
<option>15</option>
<option>20</option>
</select>
<input type="submit" value="보기">
</form>
</td>
<td colspan="3" align="right">
<%=totalCount%>개(<%=currentPage%>/<%=totalPage%>page)
</td>
</tr>

<%
if(rs.next()){
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy.MM.dd(E)");
do{
%>
<tr>
<td><%=rs.getInt("idx")%></td>
<td><%=rs.getString("name").replace("<", "&lt;").replace(">", "&gt;") %></td>
<td><%=rs.getString("memo").replace("<", "&lt;").replace(">", "&gt;") %></td>
<td><%=sdf.format(rs.getTimestamp("WriteDate"))%></td>
<td><%=rs.getString("ip") %></td>
<td align="center">
<!--삭제 또는 수정 작업시 수정 또는 삭제할 글 번호(idx)와 수정 또는 삭제후 돌아갈 페이지번호(currentPage)를 넘겨 줘야 한다-->
<input type="button" value="수정" onclick="location.href='memoUpdate.jsp?idx=<%=rs.getInt("idx")%>&currentPage=<%=currentPage%>'">
<input type="button" value="삭제" onclick="location.href='memoDelete.jsp?idx=<%=rs.getInt("idx")%>&currentPage=<%=currentPage%>'">
</td>
</tr>
<%
}while(rs.next());
}else{
%>
	<tr><td colspan="5"><marquee>테이블에 저장된 글이 없습니다</marquee></td></tr>
<% 
}
%>

<tr>
<td colspan="6" align="center">
<%
startPage=(currentPage-1)/10*10+1;
endPage=startPage+9;
endPage=endPage>totalPage?totalPage:endPage;

//===============================================================================================

if(startPage>1){
%>
	<input type="button" value="start page" onclick="location.href='?currentPage=1'"/>
	<input type="button" value="-10 page" onclick="location.href='?currentPage=<%=startPage-1%>'"/>
<%	
}else{
%>
	<input type="button" value="start page" disabled="disabled" title="이미 첫 페이지 입니다"/>
	<input type="button" value="-10 page" disabled="disabled" title="이전 10 페이지가 없습니다"/>
<%
}

if(currentPage>1){
%>
	<input type="button" value="-1 page" onclick="location.href='?currentPage=<%=currentPage-1%>'"/>
<%
}else{
%>
	<input type="button" value="-1 page" disabled="disabled" title="이전 페이지가 없습니다"/>
<%
}

//===============================================================================================

for(int i=startPage;i<=endPage;i++){
	if(currentPage == i){
%>
        <%-- <span>[<%=i%>]</span> --%>
		<input type="button" value="<%=i%>" disabled="disabled">
<%
	}else{
%>
		<%-- <a href="?currentPage=<%=i%>">[<%=i%>]</a> --%>
		<input type="button" value="<%=i%>" onclick="location.href='?currentPage=<%=i%>'">
<%		
	}
}

//===============================================================================================

if(currentPage<totalPage){
%>
	<input type="button" value="+1 page" onclick="location.href='?currentPage=<%=currentPage+1%>'"/>
<%
}else{
%>
	<input type="button" value="+1 page" disabled="disabled" title="다음 페이지가 없습니다"/>
<%
}

if(endPage<totalPage){
%>
	<input type="button" value="+10 page" onclick="location.href='?currentPage=<%=endPage+1%>'"/>
	<input type="button" value="end page" onclick="location.href='?currentPage=<%=totalPage%>'"/>
<%	
}else{
%>
	<input type="button" value="+10 page" disabled="disabled" title="다음 10 페이지가 없습니다"/>
	<input type="button" value="end page" disabled="disabled" title="이미 마지막 페이지 입니다"/>
<%
}
%>
</td>
</tr>
</table>
</body>
</html>