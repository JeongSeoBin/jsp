<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<!-- myInfo.jsp에서 넘어오는 데이터를 받는다-->
<%
//form에 입력된 데이터가 post 방식으로 전송될 때 한글이 깨지는 현상을 방지한다.
//최초로 나오는 getParameter() 메소드가 실행되기 전에 아래의 내용을 코딩하면 post 방식에서 한글이 깨지는 현상을 방지할 수 있다.
request.setCharacterEncoding("UTF-8");
//tomcat server 7.0이번 버전에서는 get방식을 사용할때도 한글이 깨진다
//get방식을 사용할때 한글이 깨지면 Server폴더의 server.xml파일을 열고 64번 줄의 Connector 태그에 URLEncoding="UTF-8"속성을 추가하면 한글이 안 깨진다
//=>서버를 설치하고 딱 한번만 하면 된다

//request.getParameter("name의 속성값"); => 이전 페이지에서 넘어오는 데이터를 받음 => 넘어오는 데이터는 무조건 문자열로 넘어온다
String name=request.getParameter("name");
out.println("이름 "+name+"<br>");
String id=request.getParameter("id");
out.println("아이디 "+id+"<br>");
String password=request.getParameter("password");
out.println("비밀번호 "+password+"<br>");
int age=0;
//사용자가 스무살이라고 입력하면
try{
age=Integer.parseInt(request.getParameter("age"));
out.println("나이 "+age+"<br>");
out.println(name+"님은 내년에 "+(age+1)+"살 입니다"+"<br>");
}catch(Exception e){
	out.println("<script>");
	out.println("alert('잘못된 나이가 입력됨')");
	out.println("</script>");	
}

boolean gender=Boolean.parseBoolean(request.getParameter("gender"));
out.println("성별 "+(gender?"남자":"여자")+"<br>");
//checkbox는 여러 항목을 선택할 수 있는데 getParameter메소드를 사용하면 가장 앞의 항목 한개만 받을 수 있다
//String hobbies=request.getParameter("hobbies");
//따라서 checkbox에서 넘어오는 데이터는 여러 항목이 넘어 올 수 있으므로 getParameterValues()로 받아서 배열에서 저장해서 처리한다
String[] hobbies=request.getParameterValues("hobbies");
//checkbox에 아무것도 안찍었을때
try{
	for(int i=0;i<hobbies.length;i++){
		if(i>0){out.println(",");}
		out.println(hobbies[i]+" ");
	}
	out.println("<br>");
}catch(Exception e){
	out.println("선택한거 없음");
}

String travel=request.getParameter("travel");
out.println("가고 싶은 여행지 "+travel+"<br>");

//태그 사용가능 줄바꿈 불가능
String content=request.getParameter("content");
//out.println(content);
//태그 사용불가 줄바꿈 불가능
//out.println(content.replace("<","&lt;").replace(">","&gt;"));
//태그 사용가능 줄바꿈 가능
//out.println(content.replace("\r\n","<br>"));
//태그 사용불가능 줄바꿈 가능//순서 중요
out.println(content.replace("<","&lt;").replace(">","&gt;").replace("\r\n","<br>"));
%>
</body>
</html>