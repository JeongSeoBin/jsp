<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%--
  이들을 사용하지 않아야 프론트앤드와 충돌을 줄임 
  <%@ ~ %> 디렉티브, 대부분 자동으로 입력된다. 설정에 관려된 정보를 적는다
  <%! ~ %> 선언부,프로그램에서 사용할 변수나 메서드를 정의 => java파일로 뽑아내서 처리
  <% ~ %> 스크립트 릿, 일반적인 jsp코드를 적는부분 => jspl 대체해서 사용
  <%= ~ %> 표현식 ,변수의 저장된 데이터나 연산결과를 출력 => EL(${~})로 대체해서 사용
--%>
<html>
<head>
<meta charset="UTF-8">
<title>회원가입</title>
</head>
<body>
<!--html은 spacebar를 여러 번 눌러도 한 칸 밖에 띄어지지 않고 enter key를 여러번 눌러도 줄이 변경되지 않는다.
	2칸 이상 띄우려면 &nbsp;를 띄울 칸의 개수 만큼 입력하고 줄을 변경하려면 <br> 태그를 사용한다-->
	
<!--현재 페이지에 입력한 데이터를 특정 페이지로 전송하려면 전송할 데이터를 입력하는 코드를 <form> ~ </form>태그내부에 작성
	action 속성에는 전송(submit) 버튼이 클릭되면 form에 입력한 데이터가 전송될 페이지 이름을 적는다.
		=> "?"만 입력하면 현재 페이지를 의미한다.
	method 속성에는 action 페이지로 데이터가 전송될 때 전송되는 정보가 url창에 표시되는 여부를 지정
		=> get이 기본값이며 전송되는 데이터가 url 창에 표시되고 post로 변경하면 표시되지 않는다.-->
<form action="myInfoOk.jsp" method="get">
<label><!--글씨클릭해도 커서가 들어감-->
<!--text는 별도로 value속성을 가지지 않지만 텍스트상자에 입력한 데이터를 value로 인식-->
<!--name : 전송할 데이터를 변수에 담아 전송 -->
이름 : <input type="text" name="name" size="40" maxlength="6" placeholder="니 이름이 뭐니"><br>
아이디 : <input type="text" name="id"><br>
<!-- type="password"일 경우 타이핑해서 한글을 입력할 수 없다. -->
비밀번호 : <input type="password" name="password"><br>
나이 : <input type="text" name="age"><br>

<!--radio와 checkbox는 같은 그룹끼리 반드시 name 속성값이 같아야 한다
<!--radio와 checkbox는 컨트롤 자체를 브라우저에 표시하는 기능밖에 없기 때문에
    action페이지에게 넘겨줄 데이터를 value속성으로 넣어줘야한다
    value속성을 지정하지않으면 체크하면 "on"이 체크하지 않으면 null이 넘어간다-->
<!--checked="checked" 새로고침했을때 체크되어 있음(둘다 한 경우 나중에 한거에 체크되어 있음)-->
성별 : <input type="radio" name="gender" checked="checked" value="true">남자
       <input type="radio" name="gender" value="false">여자<br>
취미 : <input type="checkbox" name="hobbies" value="영화보기">영화보기
       <input type="checkbox" name="hobbies" value="유투브보기">유투브보기
       <input type="checkbox" name="hobbies" value="맛있는거 먹기">맛있는거 먹기
       <input type="checkbox" name="hobbies" value="여행가기">여행가기<br>
       
<!--selected="selected" : checked와 같은 기능 -->
가고 싶은 여행지는?
<select name="travel">
 <option>괌
 <option>코타키나발루
 <option>다낭
 <option selected="selected">나트랑
 <option>푸꾸욱
 <option>보라카이
 <option>대만
</select><br>

<!--textarea는 별도로 value속성을 가지지 않지만 <textarea></textarea>사이에 입력한 데이터를 value로 인식-->
<!--<textarea></textarea>사이에는 칸을 띄우거나 줄을 변경하지 않는다-->
<!--상자안에 html태그입력하면 먹힘 엔터안먹힘--> 
<!--style = "resize:none" : 상자크기 고정-->
<textarea rows="10" cols="50" style="resize:none" name="content">입력히시오</textarea><br>
</label><br>

<input type="submit" value="회원가입">
<input type="reset" value="다시쓰기">
</form>
</body>
</html>