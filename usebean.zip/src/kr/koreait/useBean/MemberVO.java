package kr.koreait.useBean;
//VO(Value Object) => 데이터 한 건을 기억하는 클래스,DTO(Data Transfer Object),bean
//bean => 자바로 처리하는 데이터의 최소 단위
//        데이터를 저장하는 변수(필드)와 멤버변수의 데이터를 입출력할 수 있는 getter&setter메소드로만 구성된 클래스를 의미
public class MemberVO {
	//VO클래스의 멤버변수이름은 VO클레스에 저장될 데이터가 입력되는 form을 구성하는 요소들의 name속성에 지정한 이름과 반드시 같은 이름으로 만들어 져야 한다
	//데이터베이스 테이블을 사용하는 경우에도 테이블의 필드이름과 VO클레스의 멤버변수이름을 반드시 같은 이름으로 만들어야 한다
	
	private String id;
	private String name;
	private String password;
	private int age;
	private boolean gender;
	private String ip;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
	@Override
	public String toString() {
		return "MemberVO [id=" + id + ", name=" + name + ", password=" + password + ", age=" + age + ", gender="
				+ gender + ", ip=" + ip + "]";
	}
	
	

}
