<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script type="text/javascript">
function pwcheck(obj){
	pw=obj.password.value.trim();
	len=obj.password.value.trim().length;//비밀번호에 입력한 문자의 개수
	
	//**영문자,숫자,특수문자가 각각 한개이상 입력되었는지 검사**//
/*  alphaCount=0;//영문자의 개수를 셀 변수
	numCount=0;//숫자의 개수를 셀 변수
	etcCount=0;//특수문자를 셀 변수
	//입력된 비밀번호를 문자의 개수만큼 반복하며 영문자 숫자 특수문자의 개수를 샌다
	for(i=0;i<len;i++){
		if(pw.charAt(i) >= 'a' && pw.charAt(i) <='z' || pw.charAt(i) >= 'A' && pw.charAt(i) <= 'Z'){
			alphaCount+=1;
		}else if(pw.charAt(i) >= '0' && pw.charAt(i) <= '9'){
			numCount+=1;
		}else{
			etcCount+=1;
		}
	}
	if(alphaCount == 0 || numCount == 0 || etcCount == 0){
		alert('영문자,숫자,특수문자가 각각 1개이상 입력');
		obj.password.value="";
		obj.repassword.value="";
		obj.password.focus();
		return false;
	}
	//또는
	alphaCount=true;//영문자의 개수를 셀 변수
	numCount=true;//숫자의 개수를 셀 변수
	etcCount=true;//특수문자를 셀 변수
	//입력된 비밀번호를 문자의 개수만큼 반복하며 영문자 숫자 특수문자의 개수를 샌다
	for(i=0;i<len;i++){
		if(pw.charAt(i) >= 'a' && pw.charAt(i) <='z' || pw.charAt(i) >= 'A' && pw.charAt(i) <= 'Z'){
			alphaCount=false;
		}else if(pw.charAt(i) >= '0' && pw.charAt(i) <= '9'){
			numCount=false;
		}else{
			etcCount=false;
		}
	}
	if(alphaCount || numCount || etcCount){//만약에 영문자 숫자 특수문자가 있었으면 다 false로 바꼈을것
		alert('영문자,숫자,특수문자가 각각 1개이상 입력');
		obj.password.value="";
		obj.repassword.value="";
		obj.password.focus();
		return false;
	} */
	
	//**입력한 비밀번호가 8자리 이상 12자리 이하인가 검사**//
/* 	if(len < 8 || len > 12){
		alert('비밀번호는 8자리이상 12자리 이하입니다');
		obj.password.value="";
		obj.repassword.value="";
		obj.password.focus();
		return false;	
	}
	 */
	 
	 //**정규식을 이용하여 영문자 숫자 특수문자가 각각 1개이상 입력하고 8자에서 12자사이로 입력되었는지 검사 **//
	 pattern=new RegExp("^(?=.*[a-zA-z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-z0-9!@#$%^&*]{8,12}")
	//(?=.*[a-zA-z]) 영문자를 1개이상 포함했는가
	//(?=.*[0-9]) 숫자를 1개 이상 포함했는가
	//(?=.*[!@#$%^&*]) []안에 지정된 특스므수자를 1개이상 포함했는가
	//[a-zA-z0-9!@#$%^&*] []안에 지정된 문자들로만 구성되어 있는가
	//{8,12} 문자의 개수가 8자이상 12자 이하인가
	//test() 인수로 지정된 데이터가 pattern에 지정된 정규식의 조건을 만족하는가 검사
	if(!pattern.test(obj.password.value.trim())){
		alert("비밀번호는 영문자, 숫자, 특수문자(!@#$%^&*)를 각각 1개 이상 포함해야 하고 8자 이상 12자 이하로 입력해야 합니다.");
		obj.password.value="";
		obj.repassword.value="";
		obj.password.focus();
		return false;	
	}
	
	//**입력한 두개의 비밀번호가 같은가 확인**//
	if(obj.password.value.trim() != obj.repassword.value.trim()){
		alert("비밀번호를 다시 한번 확인해주세요");
		obj.password.value="";
		obj.repassword.value="";
		obj.password.focus();
		return false;
	}
	return true;
}

</script>
</head>
<body>
<form action="memberOk.jsp" method="post" onsubmit="return pwcheck2(this)"> <!--action="memberOk2.jsp" onsubmit="return pwcheck2(this)"여기 고치면서 실행  -->
<table width="500" align="center" border="1" cellpadding="5" cellspacing="0">
<tr>
<th colspan="2">회원가입</th>
</tr>
<tr>
<td width="150">id</td>
<td width="350">
  <input type="text" name="id" placeholder="아이디를 입력하시오">
  <input type="hidden" name="ip" value="<%=request.getRemoteAddr()%>">
</td>
</tr>
<tr>
<td width="150">이름</td>
<td width="350"><input type="text" name="name" placeholder="이름을 입력하시오"></td>
</tr>
<tr>
<td width="150">비밀번호</td>
<td width="350"><input type="password" name="password" placeholder="비밀번호를 입력하시오"></td>
</tr>
<tr>
<td width="150">비밀번호확인</td>
<td width="350"><input type="password" name="repassword" placeholder="비밀번호를 다시 입력하시오"></td>
</tr>
<tr>
<td width="150">나이</td>
<td width="350"><input type="text" name="age" placeholder="나이를 입력하시오"></td>
</tr>
<tr>
<td width="150">성별</td>
<td width="350">
<input type="radio" name="gender" value="true" checked="checked">남자
<input type="radio" name="gender" value="false">여자
</td>
</tr>
<tr>
<td colspan="2" align="center">
<input type="submit" value="회원가입">
<input type="reset" value="다시쓰기">
</td>
</tr>
</table>
</form>
</body>
</html>