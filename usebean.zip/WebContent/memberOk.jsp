<%@page import="kr.koreait.useBean.MemberVO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
request.setCharacterEncoding("UTF-8");
//member.jsp에서 submit버튼을 클릭하면 넘어오는 데이터를 받는다
String id=request.getParameter("id");
String password=request.getParameter("password");
String name=request.getParameter("name");
int age=Integer.parseInt(request.getParameter("age"));
boolean gender=Boolean.parseBoolean(request.getParameter("gender"));
String ip=request.getRemoteAddr();//접속자ip주소를 받는다

//member.jsp에서 넘겨받은 데이터를 저장할 VO클래스의 객체를 만들고 setter메소드로 데이터를 넣어 준다
MemberVO vo=new MemberVO();
vo.setId(id);
vo.setName(name);
vo.setPassword(password);
vo.setAge(age);
vo.setGender(gender);
vo.setIp(ip);

out.println(vo+"<br>");

%>

</body>
</html>