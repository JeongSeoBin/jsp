<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<%
	request.setCharacterEncoding("UTF-8");
%>

<!--데이터 받기
    넘어오는 데이터가 VO 클래스의 멤버로 존재하면 useBean액션 태그를 사용해서 받으면 되고 존재하지 않으면 별도로 받는다. 
    이때 넘어오는 데이터를 받는 코딩을 하지 않아도 useBean액션 태그가 실행되면 자동으로 받는다.-->
    
<!--객체 생성
    useBean 액션 태그의 id 속성에는 생성할 객체 이름을 적는다.
	useBean 액션 태그의 class 속성에는 객체를 생성할 클래스의 이름을 풀 패키지 이름과 함께 적는다.
	MemberVO vo = new MemberVO();와 같은 기능이 실행된다.-->
<jsp:useBean id="vo" class="kr.koreait.useBean.MemberVO">

<%--
<!--setter실행
	setProperty 액션 태그의 property 속성에는 setter를 실행할 멤버 변수의 이름을 적는다.
	setProperty 액션 태그의 name 속성에는 setter를 실행할 멤버 변수가 작성된 클래스의 객체의 id를 적는다.
	아래의 2줄과 같은 기능이 실행된다.
	String id = request.getParameter("id");
	vo.setId(id);
	
	태그에 입력할 내용이 없으면 마감 태그(</jsp:setProperty>)를 생략할 수 있다.
	jsp 액션 태그는 xml 문법을 따르기 때문에 마감 태그를 생략할 경우 반드시 태그 맨 뒤에 "/"를 입력해야 한다.-->
		
	<jsp:setProperty property="id" name="vo"/>
	<jsp:setProperty property="name" name="vo"/>
	<jsp:setProperty property="password" name="vo"/>
	<jsp:setProperty property="age" name="vo"/>
	<jsp:setProperty property="gender" name="vo"/>
	<jsp:setProperty property="ip" name="vo"/>
--%>
	
	<!-- property 속성에 "*"을 입력하면 form의 name 속성에 지정된 이름과 같은 모든 setter가 자동으로 실행된다. -->
	<jsp:setProperty property="*" name="vo"/>
</jsp:useBean>

<!--jsp 액션 태그를 사용해서 생성한 객체는 EL을 사용할 수 있다. -->
<%-- <%=vo%>사용가능하니까 --%>
${vo}<br/>

<!-- Date date = new Date();와 같은 기능이 실행된다. -->
<jsp:useBean id="date" class="java.util.Date"/>
${date}<br/>

</body>
</html>








