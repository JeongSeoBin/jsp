<%@page import="calendar.MyCalendar"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.Date"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>만년달력</title>
<!--css 링크로 적용  -->
<link rel="stylesheet" href="calendar.css">
</head>
<body>
<%
//컴퓨터시스템의 년,월을 얻어온다
//Date date=new Date();
//int year=date.getYear()+1900;
//int month=date.getMonth()+1;;//컴퓨터는 월을 0~11월로 저장
Calendar calendar=Calendar.getInstance();//이 클래스 객체 생성 못함 - 이미 객체가 만들어져 있어서 가져옴
int year=calendar.get(Calendar.YEAR);
int month=calendar.get(Calendar.MONTH)+1;

//이전달,다음달 하이퍼링크 또는 버튼이 클릭되면 넘어오는 년,월을 받는다
//달력이 처음 실행됐을때 이전 페이지에서 넘어오는 년,월이 없기 때문에 null을 처리 하기 위해
//또는 이전 페이지에서 숫자가 아닌 문자가 넘어올때 처리하기 위해 예외처리를 한다
try{
	year=Integer.parseInt(request.getParameter("year"));
	month=Integer.parseInt(request.getParameter("month"));
	
	if(month == 13){
		year++;
		month=1;
	}else if(month==0){
		year--;
		month=12;
	}
	
}catch(Exception e){}

%>
<!--달력 만들기-->
<table width="700" align="center" border="0">
<tr>
<th>
<%--<a href="?year=<%=year%>&month=<%=month-1%>">이전달</a>%> --%>
<input type="button" value="이전달" onclick="location.href='?year=<%=year%>&month=<%=month-1%>'">
</th>
<th id="title"><%=year%>년 <%=month%>월</th>
<th>
<%--<a href="?year=<%=year%>&month=<%=month+1%>">다음달</a>%> --%>
<input type="button" value="다음달" onclick="location.href='?year=<%=year%>&month=<%=month+1%>'">
</th>
</tr>
</table>
<table width="700" align="center" border="1" cellpadding="5" cellspacing="0">
<tr id="day">
<td class="sunday">일</td>
<td class="etcday">월</td>
<td class="etcday">화</td>
<td class="etcday">수</td>
<td class="etcday">목</td>
<td class="etcday">금</td>
<td class="saturday">토</td>
</tr>
<tr>
<%
//1일의 요일을 계산한다
int week=MyCalendar.weekDay(year, month, 1);

//주석****************************************************************
//1일이 출력될 위치를 맞추기 위해 1일의 요일만큼 반복하면서 빈칸을 출력
//for(int i=1;i<=week;i++){
%>
<!-- <td></td>브라우저마다 칸이 깨져보일 수 있다 -> <td>&nbsp;</td> -->
<!-- <td id="blank"></td> -->
<%
//}
//한줄때매 jsp열고 닫기 번거러우니까 jsp의 print로 찍을 수 있다
/*for(int i = 1; i <= week; i++) {
		out.println("<td>&nbsp;</td>");} */
//********************************************************************

//빈칸에 출력할 전 달 날짜의 시작일을 계산한다
int start=0;
if(month==1){
	start=MyCalendar.lastDay(year-1, 12)-week;//1월
}else{
	start=MyCalendar.lastDay(year,month-1)-week;//2~12월
}
//start=(month ==1)?31-week:MyCalendar.lastDay(year,month-1)-week;

//1일이 츨력될 위치를 맞추기 위해서 1일의 요일만큼 반복하며 전 달의 날짜를 출력
for(int i=1;i<=week;i++){
	if(i==1){//일요일이면
	out.println("<td class='beforesun'>" + (month==1?12:month-1) + "/" + ++start + "</td>");
	}else{
		out.println("<td class='before'>" + (month==1?12:month-1) + "/" + ++start + "</td>");
	}
}

//1일부터 그 달의 마지막 날짜까지 반복하며 날짜를 출력
boolean flag=false;//주말이 어린이날이면 true
int child=0;//진짜 어린이날의 날짜

for(int i=1;i<=MyCalendar.lastDay(year, month);i++){
	
	//대체공휴일
	//어린이날이 토요일이나 일요일인 경우 그 다음주 첫번째 비 공휴일을 대체공휴일로 지정
	if(MyCalendar.weekDay(year, 5, 5)==6){//어린이날이 토요일이니?
			flag=true;
	        child=7;//어린이날 5일이 토요일이면 월요일 7일이 대체공휴일 
		
	}else if(MyCalendar.weekDay(year, 5, 5)==0){//어린이날이 일요일이니?
			flag=true;
	        child=6;//어린이날 5일이 일요일이면 월요일 6일이 대체공휴일
	}
	
	//공휴일 표시
	//일단 양력 공휴일과 어린이날 대체공휴일만 표시
	//설날,추석,부천님 오신날은 음력이기 때문에 solatolunar.sql를 이용해서 음력,양력 대조 테이블을 jsp에 붙이고 처리해야 한다
	if(month == 1 && i == 1) {
		out.println("<td class='holiday'>" + i + "<br><span>신정</span></td>");
	} else if(month == 3 && i == 1) {
		out.println("<td class='holiday'>" + i + "<br><span>삼일절</span></td>");
	} else if(month == 5 && i == 5) {
		out.println("<td class='holiday'>" + i + "<br><span>어린이날</span></td>");
	} else if(month == 6 && i == 6) {
		out.println("<td class='holiday'>" + i + "<br><span>현충일</span></td>");
	} else if(month == 8 && i == 15) {
		out.println("<td class='holiday'>" + i + "<br><span>광복절</span></td>");
	} else if(month == 10 && i == 3) {
		out.println("<td class='holiday'>" + i + "<br><span>개천절</span></td>");
	} else if(month == 10 && i == 9) {
		out.println("<td class='holiday'>" + i + "<br><span>한글날</span></td>");
	} else if(month == 12 && i == 25) {
		out.println("<td class='holiday'>" + i + "<br><span>크리스마스</span></td>");
	}else if(flag && month ==5 && i==child){
		out.println("<td class='holiday'>" + i + "<br><span>대체공휴일</span></td>");		
	}else{
	//공휴일이 아닌 일반 날짜를 요일별로 색 다르게 출력
	switch(MyCalendar.weekDay(year, month, i)) {
			case 0: // 일요일
				out.println("<td class='sun'>" + i + "</td>");
				break;
			case 6: // 토요일
				out.println("<td class='sat'>" + i + "</td>");
				break;
			default:
				out.println("<td class='etc'>" + i + "</td>");
				break;
		}
	}
	
//출력한 날짜가 토요일이고 마지막 날짜가 아니면 줄을 바꾼다
//만약 토요일이 마지막 날짜인데 줄을 바꾸면 빈줄 하나가 생겨 버린다
    if(MyCalendar.weekDay(year, month, i)==6 && i != MyCalendar.lastDay(year, month)){
    	out.println("</tr><tr>");
    }
}

//다음달 1일의 요일을 계산한다
if(month==12){
	week=MyCalendar.weekDay(year+1, 1, 1);
}else{
	week=MyCalendar.weekDay(year, month+1, 1);
}
//week=(month==12)?MyCalendar.weekDay(year+1, 1, 1):MyCalendar.weekDay(year, month+1,1);

//날짜를 다 출력하고 남은 칸에 다음 달의 날짜를 1일부터 토요일까지 반복하며 출력
if(week != 0){
	start=0;
	for(int i=week;i<=6;i++){
		if(i==week){
			out.println("<td class='afterfirst'>"+ (month==12?1:month+1) +"/"+ ++start + "</td>");
		}
		else if(i==6){
		out.println("<td class='aftersat'>"+ (month==12?1:month+1) +"/"+ ++start + "</td>");}
		else{
			out.println("<td class='after'>"+ (month==12?1:month+1) +"/"+ ++start + "</td>");
		}
	}
}
%>
</tr>

<!--년,월을 선택하고 보기버튼을 클릭하여 한번에 이동 -->
<tr>
<td colspan="7">
<form action="?" method="post">
<select name="year">
<%
for(int i=1950;i<=2050;i++){
	if(i==calendar.get(Calendar.YEAR)){
		out.println("<option select='selected'>"+i+"</option>");	
	}else{
		out.println("<option>"+i+"</option>");	
	}
}
%>
</select>년&nbsp;
<select name="month">
<%
for(int i=1;i<=12;i++){
	if(i==calendar.get(Calendar.MONTH)+1){
		out.println("<option select='selected'>"+i+"</option>");	
	}else{
		out.println("<option>"+i+"</option>");	
	}
}
%>
</select>월&nbsp;
<input type="submit" value="보기">
</form>
</td>
</tr>
</table>
</body>
</html>