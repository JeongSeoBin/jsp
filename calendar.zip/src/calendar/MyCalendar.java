package calendar;
//달력에 필요한 메서드를 모아 놓은 클래스
public class MyCalendar {
	
	//윤년/평년 판별 메소드
	//년도를 넘겨 받아 윤년/평년을 판단해 윤년이면 true, 평년이면 false를 리턴하는 메서드
	public static boolean isLeapYear(int year){
		//년도가 4로 나눠 떨어지고 100으로 나눠 떨어지지 않거나 400으로 나눠 떨어지면 윤년,그렇지 않으면 평년
		return year%4==0 && year%100!=0 || year%400==0;
	}
	
	//년,월을 넘겨 받아 그 달의 마지막 날짜를 리턴하는 메소드
	public static int lastDay(int year,int month) {
		//각 달의 마지막 날짜를 기억하는 배열을 만든다
		int [] m= {31,28,31,30,31,30,31,31,30,31,30,31};
		//2월의 마지막날짜를 결정(평년이면 28 윤년이면 29)
		m[1]=isLeapYear(year)?29:28;
		//마지막 날짜를 리턴
		return m[month-1];
	}
	
	//년,월,일을 인수로 넘겨 받아 1년1월1일부터 지나온 날짜의 합계를 리턴하는 메소드
	public static int totalDay(int year,int month,int day) {
		//1년1월1일부터 전 년도 12월31일까지 지난 날짜를 계산
		//평년이면 365일이고 윤년이면 366일
		int sum=(year-1)*365 + (year-1)/4 - (year-1)/100 + (year-1)/400;
		//전 년도까지 지난 날짜의 합계에 전 달까지 지난 날짜를 더한다
		for(int i=1;i<month;i++) {
			sum+=lastDay(year,i);//i대신 moth를 쓰면 같은 달만 께속 더해진다
		}
		//전 달까지 지난 날짜의 합계에 일을 더해서 리턴시킨다
		return sum+day;	
	}
	
	//년,월,일을 인수로 넘겨 받아 요일을 숫자로 리턴하는 메소드
	//일0 월1 화2 수3 목4 금5 토6
	public static int weekDay(int year,int month,int day) {
		return totalDay(year, month, day)%7;
	}

}
