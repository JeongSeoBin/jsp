<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<!--로그인 성공 했을때 login을 yes로 하고 로그아웃했을때 login을 지워서
    login이 yes일때만 로그인성공&로그아웃버튼 띄우고 나머지는 초기화면 띄운다  -->
<%
request.setCharacterEncoding("UTF-8");
String id="";
String password="";
try{
	//로그인창에서 입력해서 널이 아니므로 로그인버튼 클릭해서 넘어온 데이터를 받는다
	id=request.getParameter("id").trim();
	password=request.getParameter("password").trim();
}catch(Exception e){
	//맨 처음에는 받은게 없으므로 id,password 값이 널로 유지 -> 쭉 실행안하고 초기화면으로 간다
}

/* 로그인 처리 */
//id가 hong이고 password가 123456이면 로그인처리
if(id.equals("hong") && password.equals("123456")){
	//로그인이 되었으므로 로그인정보를 session에 저장
	session.setAttribute("id", id);
	session.setAttribute("name","관리자");
	session.setAttribute("login","yes");
	//로그인 성공 alert창
	out.println("<script>");
	out.println("alert('"+ session.getAttribute("name") + "(" + id + ")님 안녕하세요')");
	out.println("</script>");	
}else if(id.length() + password.length() != 0){//뭐라도 입력했을때//이 조건 없으면 실행하자마자 '아이디 또는 비밀번호가 올바르지 않습니다.' 뜸
	out.println("<script>");
	out.println("alert('아이디 또는 비밀번호가 올바르지 않습니다')");
	out.println("</script>");
}

/* 로그아웃 처리 */
//로그아웃버튼이 클릭되면 넘어오는 데이터(logout)를 받는다
String logout=request.getParameter("logout");
//로그아웃정보가 넘어왔으면 로그아웃처리
if(logout != null && logout.equals("yes")){
	out.println("<script>");
	out.println("alert('" + session.getAttribute("name") + "(" + session.getAttribute("id") + ")님 안녕히가세요')");
	out.println("</script>");
	//로그아웃되었으므로 session에서 로그인 정보 지움
	session.removeAttribute("id");
    session.removeAttribute("name");
    session.removeAttribute("login");	
}

/* 이동하는 창은 둘 중 하나, 로그인 성공시 창 아니면 초기화면 */
String login=(String)session.getAttribute("login");
if(login != null && login.equals("yes")){
	%>
	로그인 성공<br>
	<%=session.getAttribute("name") %>(<%=session.getAttribute("id") %>)님 안녕하세요<br>
	${name}(${id})님 안녕하세요<br>
	 <input type="button" value="로그아웃" onclick="location.href='?logout=yes'">
<%	
}else{
%>
<!--초기화면-->
<!-- 아이디와 비밀번호를 입력받는다 -->
<form action="?" method="post">
아이디 <input type="text" name="id"><br>
비밀번호 <input type="password" name="password"><br>
<input type="submit" value="로그인"> 
</form>
<%	
}
%>
</body>
</html>