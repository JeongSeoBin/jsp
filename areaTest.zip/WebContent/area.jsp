<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<!-- 
#형변환
#EL
#forward & sendRedirect
#setAttribute & getAttribute
 -->
<body>
<%
//jsp에서 사용하는 시스템영역과 유효범위
//pageContext => 현재 보고 있는 페이지
//request => 현재 보고 있는 페이지와 다음 페이지 까지
//session => 브라우저가 실행되면 생성되고 브라우저가 종료되면 소멸되는 영역
//application => 서버가 실행되면 생성되고 서버가 종료되면 소멸되는 영역

String str="그냥 변수";//일반 변수

//영역변수가 저장되는 기억공간은 영역변수이름을 key로하고 영역변수에 저장되는 데이터를 value로 하는 Map(String,Object)형태의 자료구조이다
//-> value의 자료형이 object인 이유는 개발자가 어떤 타입의 데이터를 영역변수에 저장할지 모르기 때문이다

//영역변수에 데이터 저장하기
//영역이름.setAttribute("영역변수이름",영역변수에 저장할 데이터)
pageContext.setAttribute("pageContextVar","area.jsp의 pageContext영역변수");
request.setAttribute("requestVar", "area.jsp의 request영역변수");
session.setAttribute("sessionVar","area.jsp의 session영역변수");
application.setAttribute("applicationVar","area.jsp의 application영역변수");

out.println("그냥변수 : " + str + "<br>");

//영역변수에 저장된 데이터 가져오기
//영역이름.getAttribute("영역변수이름")
//영역변수가 저장되는 기억공간은 Map(String,Object)형태이므로 getAttribute()로 영역변수에 저장된 데이터를 얻어 오면 Object 타입으로 얻어 온다
// ->영역 변수에 저장된 데이터를 얻어와서 일반 변수에 저장하려면 반드시 일반 변수의 자료형으로 형변환시켜야 한다.
String pageContextVar=(String)pageContext.getAttribute("pageContextVar");
out.println("area.jsp의 pageContext 영역변수 : " + pageContextVar+"<br>");
out.println("area.jsp의 request 영역 변수 : " + request.getAttribute("requestVar") + "<br>");
out.println("area.jsp의 session 영역 변수 : " + session.getAttribute("sessionVar") + "<br>");
out.println("area.jsp의 application 영역 변수 : " + application.getAttribute("applicationVar") + "<br>");

//sendRedirect()는 request영역에 저장된 데이터를 가지지 않고 인수로 지정된 페이지로 넘어 간다
//sendRedirect()는 단순히 페이지만 이동시키는 기능을 실행한다
//sendRedirect()는 url에 표시된 페이지이름이 인수로 지정된 페이지로 변경된다
response.sendRedirect("requestTest.jsp");

//forward() 메소드는 request 영역에 저장된 데이터를 가지고 인수로 지정된 페이지로 넘겨 준다.
//forward() 메소드는 단순히 현재 페이지의 데이터를 다음 페이지로 이동시키는 기능을 실행한다.
//forward() 메소드는 url에 표시되는 페이지 이름이 인수로 지정된 페이지로 변경되지 않는다.
//=> 브라우저에는 requestTest.jsp 페이지의 데이터가 표시되지만 실제로는 area.jsp 페이지에 있다.
//=> 새로고침을 실행하면 area.jsp 페이지 부터 다시 시작된다.
//pageContext.forward("requestTest.jsp");
%>
</body>
</html>