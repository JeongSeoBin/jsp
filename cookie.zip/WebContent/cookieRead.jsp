<%@page import="java.net.URLDecoder"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
//클라이언트가 쿠키를 읽어 올때는 여러개의 쿠키를 한꺼번에 읽어 오기 때문에 배열로 받는다
Cookie[] cookies=request.getCookies();
//out.println(cookies+"<br>");

//실행시 write먼저 실행후 read실행
//jsessionid : jsp가 session에서 사용하는 시스템 쿠키로 동일한 사용자의 접근여부를 판단

for(Cookie cookie:cookies){
	//out.println(cookie+"<br>");
	out.println("쿠키이름"+cookie.getName()+"<br>");
	out.println("쿠키내용"+cookie.getValue()+"<br>");
	
	//내용이 한글인 쿠키를 저장할때는 에러가 발생하기 때문에 반드시 인코딩을 거쳐 저장해야 했지만 읽어 올때는 그냥 읽어도 에러가 발생되지 않는다
	//다만, 인코딩된 유니코드 자체가 출력되기 때문에 읽을 수 없다 즉, getValue()메서드로 그냥 읽으면 유니코드로 읽어온다
	//->저장된 내용이 한글인 쿠키를 읽어 올때는 디코딩과정을 거쳐야 한글을 읽을 수 있다
	out.println(cookie.getName()+":"+ 
	URLDecoder.decode(cookie.getValue(),"UTF-8")+"<br>");	
}
%>

</body>
</html>