<%@page import="java.net.URLEncoder"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
//쿠키는 서버가 클라이언트에게 남기는(보내는)작은 정보 조각을 말한다
//쿠키를 만들때는 한번에 한개씩 만들고 읽어 올때는 한꺼번에 모두 읽어 온다

//new Cookie("쿠키이름",쿠키내용)
Cookie cookie=new Cookie("id","hong");//쿠키를 만든다
response.addCookie(cookie);//서버가 쿠키를 클라이언트에게 보낸다

//한글인코딩문제로 쿠키를 클라이언트에게 보낼때 에러발생
//Cookie cookie2=new Cookie("name","아롱이");
//response.addCookie(cookie2);
//쿠키내용으로 한글을 사용할려면 UTF-8로 반드시 인코딩해야한다
Cookie cookie2=new Cookie("name",URLEncoder.encode("아롱이","UTF-8"));

//setMaxAge(10) : 인수로 지정된 초만큼 쿠키가 클라이언트에서 유지되는 시간을 설정한다
//cookie2.setMaxAge(10);
response.addCookie(cookie2);  
%>
쿠키저장완료
</body>
</html>