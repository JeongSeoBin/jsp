<%@page import="kr.koreait.onLinePoll.PollRead"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<!--파일읽기 & 파일쓰기 사용법-->
<body>
<%
//읽어 들일 텍스트파일이 위치한 웹 서버상의 실제 경로와 파일이름을 지정
String filename=application.getRealPath("/")+"poll.txt";//application.getRealPath("/") : 현재 실행중인 프로그램이 구동되는 웹 서버의 실제 경로를 얻어온다. 
//out.println(application.getRealPath("/") + "poll.txt");

//텍스트파일의 데이터를 읽어오는 메소드를 실행해서 리턴된 결과를 ArrayList에 저장
ArrayList<String> poll=PollRead.pollRead(filename);
//읽어들인 텍스트파일의 데이터 전체를 출력
//for(String str:poll){
//	out.println(str+"<br>");
//}

//투표항목의 개수를 계산
int itemCount=(poll.size()-1)/2;//제목뺌
//out.println("투표항목의 개수는 "+itemCount+"<br>");
%>

<form action="pollWrite.jsp" method="get">
<table width="500" align="center" border="1" bordercolor="blue" cellspacing="0" cellpadding="5">
<!-- 투표제목을 출력 -->
<tr height="50" bgcolor=#81DAF5><th><%=poll.get(0)%></th></tr>
<!--투표항목의 개수만큼 반복하며 라디오버튼과 투표항목을 출력-->
<%
for(int i=1;i<=itemCount;i++){
%>
<tr height="35" bgcolor=#CEF6F5>
 <td>
  <input type="radio" name="poll" value=<%=i%>><!--투표항목은 숫자로 넘긴다-->
  <%=poll.get(i)%>
 </td>
</tr>
<%
}
%>
<tr bgcolor=#81DAF5>
<td align="center">
<input type="submit" value="투표하기">
<input type="button" value="결과보기" onclick="location.href='pollResult.jsp'">
</td>
</tr>
</table>
</form>
</body>
</html>