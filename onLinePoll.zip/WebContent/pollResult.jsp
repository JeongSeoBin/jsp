<%@page import="java.text.DecimalFormat"%>
<%@page import="kr.koreait.onLinePoll.PollRead"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<!--지정된 시간이 지나면 특정 사이트로 이동-->
<meta http-equiv="refresh" content="5, url='http://www.naver.com/'">

<!--지정된 시간이 지나면 현재 페이지 새로 고침 -->
<!--실시간 갱신-->
<meta http-equiv="refresh" content="5, url=?">
<title>Insert title here</title>
</head>
<body>
<%
//투표결과를 브라우저에 출력하기 위해서 텍스트파일의 데이터를 읽어오고 투표항목의 개수를 계산
String filename=application.getRealPath("/"+"poll.txt");
ArrayList<String> poll=PollRead.pollRead(filename);
int itemCount=(poll.size()-1)/2;

//득표율을 출력하기 위해 총 득표수 계산
int sum=0;
for(int i=itemCount+1;i<poll.size();i++){
	sum+=Integer.parseInt(poll.get(i));	
}

//숫자 데이터 출력 서식을 지정
//DecimalFormat("#,##0원하는 단위 입력");
//(#의미 없는 0은 출력하지 않는다,데이터자체가 0일때는 처리)
//ㄹ+한자=>단위
DecimalFormat df1=new DecimalFormat("#,##0표");
DecimalFormat df2=new DecimalFormat("#,##0.00%");
%>
<table width="500" align="center" border="1" cellspacing="0" cellpadding="5">
<tr height="50"><th colspan="2"><%=poll.get(0) %></th></tr>
<!--전체 투표수 출력 -->
<tr height="35"><td align="right" colspan="2">전체 득표수 : <%=df1.format(sum)%></td></tr>
<!--투표항목개수만큼 반복하며 투표항목,득표수,막대그래프 출력 -->
<%
for(int i=1;i<itemCount;i++){
	int pyo=Integer.parseInt(poll.get(i+itemCount));//득표수
	double per=(double)pyo/sum;//득표율
	%>
	<tr height="35">
	<!--투표항목,득표수 -->
	<td width="150">
	<%=poll.get(i)%>(<%=df1.format(pyo)%>)
	</td>
	<!-- 막대그래프 -->
	<td width="350">
	<hr width="<%=350*per%>" size="10" color="pink" align="left">
	</td>
	</tr>
<% 
}
%>
<tr>
<td colspan="2" align="center">
<input type="button" value="투표하러 가기" onclick="location.href='pollRead.jsp'">
</td>
</tr>
</table>
</body>
</html>