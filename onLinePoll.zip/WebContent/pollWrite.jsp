<%@page import="kr.koreait.onLinePoll.PollWrite"%>
<%@page import="kr.koreait.onLinePoll.PollRead"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
request.setCharacterEncoding("UTF-8");
//pollRead.jsp에서 넘어온 투표데이터를 받는다
String temp=request.getParameter("poll");

//투표데이터가 넘어왔나(null이나 공백이 아닌가)검사 -> 반드시 null검사를 먼저 한다
if(temp != null && temp.trim().length()>0){
	//투표데이터가 숫자인지 검사
	try{
		//넘어온 데이터가 숫자인 경우 데이터가 투표범위내에 해당되는가를 검사하기 위해
		//텍스트파일을 읽고 투표항목의 개수를 가져온다
		String filename=application.getRealPath("/")+"poll.txt";
		ArrayList<String> poll=PollRead.pollRead(filename);
		int itemCount=(poll.size()-1)/2;
		
		int result=Integer.parseInt(temp);
		
		//넘어온 데이터가 정상적인 투표범위의 데이터인가 검사
		if(result>=1 && result<=itemCount){
			//여기까지 왔다는 것은 정상적인 투표데이터가 넘어왔다는 것이므로 투표항목의 득표수를 증가
		    int index=result+itemCount;//득표수를 증가시킬 위치
		    result=Integer.parseInt(poll.get(index))+1;//득표수를 증가시킴 => ArrayList의 index번째 데이터를 증가 시킨다
		    poll.set(index,result+"");//증가된 득표수를 ArrayList에 저장
		    
		    //투표결과가 저장된 ArrayList의 데이터를 텍스트파일로 출력(쓰기)
		    PollWrite.pollWrite(filename, poll);
		    
		    //투표결과보기 페이지로 넘어감 (메시지 출력안하고 바로 넘어감)
		    response.sendRedirect("pollResult.jsp");
		}else{
			//넘어온 데이터가 정상적인 투표범위가 아니므로 오류메시지출력하고 pollRead.jsp페이지로 이동
			out.println("<script>");
			out.println("alert('정상적인 투표범위가 아닙니다')");
			out.println("location.href='pollRead.jsp'");
			out.println("</script>");
		}
		
	}catch(Exception e){
		//투표데이터가 숫자가 아니므로 오류메시를 출력하고 pollRead.jsp로 이동
		out.println("<script>");
		out.println("alert('투표데이터가 숫자가 아닙니다')");
		out.println("location.href='pollRead.jsp'");//오류창의 확인버튼 눌렀을때 투표화면으로 이동
		out.println("</script>");
	}
}else{
	//투표데이터가 넘어오지 않았으므로 오류메시지를 출력하고 pollRead.jsp로 이동
	out.println("<script>");
	out.println("alert('투표하세요')");
	out.println("location.href='pollRead.jsp'");//오류창의 확인버튼 눌렀을때 투표화면으로 넘어감
	out.println("</script>");
	
	//오류메시지출력안하고 페이지 이동
	//response.sendRedirect("pollRead.jsp");
	//jsp는 서버용 스크립트언어 자바스크립트는 클라이언트용 스크립트언어
	//하나의 jsp파일에 서버용 스크립트언어와 클라이언트용 스크립트언어가 모두 사용된 경우
	//서버용 스크립트언어가 먼저 실행도히고 난 후 클라이언트용 스트립트언어가 실행->코딩순서와 상관없음
}
%>
</body>
</html>