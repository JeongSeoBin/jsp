<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<!--MSIE는 content속성에 시간을 지정한 후 ";"를 찍어야 url에 지정된 페이지로 이동  -->
<meta http-equiv="refresh" content="5; url='http://www.naver.com'">
</head>
<body>
페이지가 없거나 이동되었거나 삭제되었습니다
5초후에 자동으로 네이버로 이동합니다
</body>
</html>
<!-- MSIE는 자체적으로 에러메시지페이지를 가지고 있다
사용자 에러메시지페이지의 크기가 512바이트 이하일 경우 
사용자정의 에러메시지페이지를 표시하지않고 MISE자체 에러메시지페이지를 보여줌 -->
