<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
서버에 중대한 문제가 발생
빠른 시간내에 복구하겠습니다
</body>
</html>
<!--MSIE는 자체적으로 에러메시지퍼이지를 가지고 있다
사용자 에러 메시지 페이지의 크기가 512바이트 이하일 경우 사용자 정의 에러 메시지를 표시하지 않고
MSIE자체 에러메시지 페이지를 보여준다  -->
