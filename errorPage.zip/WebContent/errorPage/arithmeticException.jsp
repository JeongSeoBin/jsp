<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
나눗셈은 0으로 할 수 없습니다.
</body>
</html>
<!--바이트 늘림
	MSIE는 자체적으로 에러 메시지 페이지를 가지고 있다.
	사용자 에러 메시지 페이지의 크기가 512 바이트 이하일 경우 사용자 정의 에러 메시지를 표시하지 않고 MSIE 자체
	에러 메시지 페이지를 보여준다.
-->