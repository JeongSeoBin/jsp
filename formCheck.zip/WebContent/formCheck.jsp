<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script type="text/javascript" src="juminCheck.js">
</script>
</head>
<!--onload 이벤트는 현재 페이지가 브라우저에 표시(로드)되고 난 후 자동으로 실행-->
<body onload="document.juminForm.jumin1.focus()"><!--창이 실행 되자마자 커서가 깜빡임  -->

<!--onsubmit 이벤트는 form의 submit버튼을 클릭하면 실행되는 이벤트-->
<!--onsubmit 이벤트에서 폼에 입력된 내용이 정상적으로 입력되었나 검사하는 javascript함수를 실행하고 검사결과가 정상이면 true, 오류가 발생하면 false를 리턴하게 만든다-->
<!--onsubmit="return javascript함수(this)"형태로 코딩하면 javascript함수 실행결과가 true이면 action에서 지정한 페이지로 넘어가고 false이면 현재 페이지에 그대로 머문다 -->
<form action="juminOk.jsp" name="juminForm" method="post" onsubmit="return formCheck(this)">

<!--onkeydown 이벤트는 키를 누르는 순간 실행되는 이벤트
    onkeypress 이벤트는 키를 누르고 있을때 실행되는 이벤트
    onkeyup 이벤트는 키보드에서 손가락이 떨어지는 순간 실행되는 이벤트-->
<input type="text" name="jumin1" maxlength="6" onkeyup="moveNext(this,6,document.juminForm.jumin2)">
-
<input type="text" name="jumin2" maxlength="7" onkeyup="moveNext(this,7,document.juminForm.sendbtn)">
<input type="submit" value="검사하기" name="sendbtn">
</form>
</body>
</html>