select * from CUSTOMERHOTEL;
select * from hotel;
select * from ROUTE;
select * from CUSTOMERHOTEL;
select * from CUSTOMERFLIGHT;
select * from traffic;
select * from CUSTOMERTRAFFIC;
select * from CUSTOMERTICKET;

DELETE FROM HOTEL;
drop sequence hotel_idx_seq;
create sequence hotel_idx_seq;

DELETE from TRAFFIC;
drop SEQUENCE traffic_idx_seq;
create SEQUENCE traffic_idx_seq;

delete from CUSTOMERFLIGHT;
drop sequence CUSTOMERFLIGHT_idx_seq;
create sequence CUSTOMERFLIGHT_idx_seq;

delete from CUSTOMERHOTEL;
drop sequence CUSTOMERHOTEL_idx_seq;
create sequence CUSTOMERHOTEL_idx_seq;

delete from CUSTOMERTRAFFIC;
drop sequence CUSTOMERTRAFFIC_idx_seq;
create sequence CUSTOMERTRAFFIC_idx_seq;

delete from CUSTOMERTICKET;
drop sequence CUSTOMERTICKET_idx_seq;
create sequence CUSTOMERTICKET_idx_seq;

delete from ROUTE;
drop sequence route_idx_seq;
create sequence route_idx_seq;

insert into traffic (idx, STARTINGPOINT, DESTINATION, DEPARTUREYEAR, DEPARTUREMONTH, DEPARTUREDATE, ARRIVEYEAR, ARRIVEMONTH, ARRIVEDATE) 
values (traffic_idx_seq.nextval, '방콕', '파타야', 2020,5,22,2020,5,22);
insert into traffic (idx, STARTINGPOINT, DESTINATION, DEPARTUREYEAR, DEPARTUREMONTH, DEPARTUREDATE, ARRIVEYEAR, ARRIVEMONTH, ARRIVEDATE) 
values (traffic_idx_seq.nextval, '파타야', '씨엠립', 2020,5,24,2020,5,24);
insert into traffic (idx, STARTINGPOINT, DESTINATION, DEPARTUREYEAR, DEPARTUREMONTH, DEPARTUREDATE, ARRIVEYEAR, ARRIVEMONTH, ARRIVEDATE) 
values (traffic_idx_seq.nextval, '방콕', '사파', 2020,5,22,2020,5,22);

insert into hotel (IDX, CITY, CHECKINYEAR, CHECKINMONTH, CHECKINDATE, CHECKOUTYEAR, CHECKOUTMONTH, CHECKOUTDATE) 
values (hotel_idx_seq.nextval,'방콕',2020,5,20,2020,5,22 );
insert into hotel (IDX, CITY, CHECKINYEAR, CHECKINMONTH, CHECKINDATE, CHECKOUTYEAR, CHECKOUTMONTH, CHECKOUTDATE) 
values (hotel_idx_seq.nextval,'파타야',2020,5,22,2020,5,24 );
insert into hotel (IDX, CITY, CHECKINYEAR, CHECKINMONTH, CHECKINDATE, CHECKOUTYEAR, CHECKOUTMONTH, CHECKOUTDATE) 
values (hotel_idx_seq.nextval,'씨엠립',2020,5,24,2020,5,25 );
insert into hotel (IDX, CITY, CHECKINYEAR, CHECKINMONTH, CHECKINDATE, CHECKOUTYEAR, CHECKOUTMONTH, CHECKOUTDATE) 
values (hotel_idx_seq.nextval,'사파',2020,5,20,2020,5,22 );

insert into ticket (IDX, CITY, ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '방콕', 2020, 5, 20);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '방콕', 2020,5,21);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '방콕', 2020,5,22);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '방콕', 2020,5,23);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '파타야', 2020,5,22);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '파타야', 2020,5,23);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '파타야', 2020,5,24);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '파타야', 2020,5,25);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '씨엠립', 2020,5,24);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '씨엠립', 2020,5,25);
insert into ticket (idx, CITY,ENTRANCEYEAR, ENTRANCEMONTH, ENTRANCEDATE) 
values (ticket_idx_seq.nextval, '사파', 2020,5,24);
create sequence ticket_idx_seq;
create sequence customerTicket_idx_seq;

commit;