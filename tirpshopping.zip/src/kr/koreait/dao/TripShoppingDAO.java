package kr.koreait.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.vo.CustomerVO;
import kr.koreait.vo.FlightList;
import kr.koreait.vo.FlightVO;
import kr.koreait.vo.HotelVO;
import kr.koreait.vo.NationalityCategoryList;
import kr.koreait.vo.NationalityCategoryVO;
import kr.koreait.vo.RouteList;
import kr.koreait.vo.RouteVO;
import kr.koreait.vo.TicketVO;
import kr.koreait.vo.TrafficVO;

public class TripShoppingDAO {
	private static TripShoppingDAO instance=new TripShoppingDAO();
	private TripShoppingDAO() {}
	public static TripShoppingDAO getInstance() {return instance;}
	
	//TripSoppingService에서 호출되어 mapper와 회원가입 정보가 들어 있는 객체를 넘겨 받고
	//customer 테이블에 회원가입 정보를 insert하는 customer.xml의 insert 명령을 실행한다
	public void signUp(SqlSession mapper,CustomerVO vo) {
		System.out.println("TripShoppingDAO의 signUp 실행");
		mapper.insert("signUp", vo);
	}
	
	//TripShoppingService에서 호출되어 mapper와 로그인 정보가 들어 있는 객체를 넘겨 받고 
	//customer 테이블에서 로그인 정보에 해당하는 회원정보를 select하는 customer.xml의 select 명령을 실행한다
	public CustomerVO checkCustomer(SqlSession mapper,CustomerVO vo) {
		System.out.println("TripShoppingDAO의 checkCustomer 실행" );
		return (CustomerVO) mapper.selectOne("checkCustomer", vo);
	}
	
	//TripShoppingService에서 호출되어 mapper를 넘겨 받고
	//customer 테이블에서 모든 회원의 id 리스트를 가져오는 customer.xml의 select 명령을 실행한다
	public ArrayList<String> selectIdList(SqlSession mapper){
		System.out.println("TripShoppingDAO의 selectIdList() 실행" );
		return (ArrayList<String>) mapper.selectList("selectIdList");
	}
	
	//TripShoppingService에서 호출되어 mapper와 continent가 저장된 객체를 넘겨 받고
	//nationalityCategory테이블에 continent를 저장하는 nationalityCategory.xml의 insert 명령을 실행한다
	public void continentInsert(SqlSession mapper, NationalityCategoryVO vo) {
		System.out.println("TripShoppingDAO의 continentInsert() 실행" );
		mapper.insert("continentInsert", vo);
	}
	
	///TripShoppingService에서 호출되어 mapper를 넘겨 받고
	//nationalityCategory테이블에서 전체 카테고리 목록을 가져 오는 nationalityCategory.xml의 select 명령을 실행한다
	public ArrayList<NationalityCategoryVO> selectNationalityCategoryList(SqlSession mapper){
		System.out.println("TripShoppingDAO의 selectNationalityCategoryList 실행");
		return (ArrayList<NationalityCategoryVO>) mapper.selectList("selectNationalityCategoryList");	
	}
	
	//TripShoppingService에서 호출되어 mapper와 continentRef를 넘겨 받고
	//nationalityCategory테이블에서 continent에 해당하는 카테고리 목록을 가져 오는 nationalityCategory.xml의 select 명령을 실행한다
	public ArrayList<NationalityCategoryVO> selectNationalityCategoryList2(SqlSession mapper,int continentRef){
		System.out.println("TripShoppingDAO의 selectNationalityCategoryList2() 실행");
		return (ArrayList<NationalityCategoryVO>) mapper.selectList("selectNationalityCategoryList2",continentRef);
	}
 	
	//TripShoppingServic에서 호출되어 mapper와 ref, seq가 저장된 HashMap 객체를 넘겨 받고 
	//같은 카테고리 그룹에서 카테고리의 출력 순서를 조정하기 위해 seq를 1증가 시키는
	//nationalityCategory.xml의 update sql 명령을 실행하는 메소드
	public void increment(SqlSession mapper,HashMap<String, Integer> hmap) {
		System.out.println("TripShoppingDAO클래스의 increment() 메소드 실행");
		mapper.update("increment",hmap);
	}
	
	//TripShoppingServic에서 호출되어 mapper와 서브카테고리(travelDestination)가 저장된 객체를 넘겨 받고
	//nationalityCategory테이블에 travelDestination을 저장하는 nationalityCategory.xml의 insert 명령을 실행한다
	public void travelDestinationInsert(SqlSession mapper,NationalityCategoryVO vo) {
		System.out.println("TripShoppingDAO클래스의 travelDestinationInsert() 메소드 실행");
		mapper.insert("travelDestinationInsert", vo);
	}
	
	//TripShoppingService에서 호출되어 mapper와 continent를 넘겨 받고
	//nationalityCategory테이블에서 name이 continent인 카테고리의 ref를 가져 오는 nationalityCategory.xml의 select 명령을 실행한다
	public int selectContinentRef(SqlSession mapper,String continent) {
		System.out.println("TripShoppingDAO클래스의  selectContinentRef()메소드 실행");
		return (int) mapper.selectOne("selectContinentRef", continent);	
	}
	
	//TripShoppingService에서 호출되어 mapper와 routeVO를 넘겨 받고
	//route테이블에 루트 한 건을 저장하는 route.xml의 insert 명령을 실행한다
	public void routeInsert(SqlSession mapper,RouteVO vo) {
		System.out.println("TripShoppingDAO클래스의  routeInsert()메소드 실행");
		mapper.insert("routeInsert", vo);
	}
	
	//TripShoppingService에서 호출되어 mapper를 넘겨 받고
	//route 테이블에서 전체 루트 리스트를 가져오는 route.xml의 select 명령을 실행한다
	public ArrayList<RouteVO> selectRouteList(SqlSession mapper) {
		System.out.println("TripShoppingDAO클래스의  selectRouteList()메소드 실행");
		return  (ArrayList<RouteVO>) mapper.selectList("selectRouteList");
	}
	
	//TripShoppingService에서 호출되어 mapper를 넘겨 받고
	//customerflight 테이블에서 전체 개수를 얻어 오는 flight.xml 의 select 명령을 실행한다
	public int selectTotalCount(SqlSession mapper) {
		System.out.println("TripShoppingDAO클래스의 selectTotalCount()메소드 실행");
		return (int) mapper.selectOne("selectTotalCount");
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 IN항공권을 얻기 위한 조건들을 묶은 flightVO와 mapper를 넘겨 받고
	//flight 테이블에서 고객이 선택한 루트에 맞는 IN항공리스트를 가져오는 flight.xml의 select 명령을 실행한다
	public ArrayList<FlightVO> selectInFlightList(SqlSession mapper,FlightVO flightVO){
		System.out.println("TripShoppingDAO클래스의 selectInFlightList() 메소드 실행");
		return (ArrayList<FlightVO>) mapper.selectList("selectInFlightList", flightVO);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 OUT항공권을 얻기 위한 조건들을 묶은 flightVO2와 mapper를 넘겨 받고
	//flight 테이블에서 고객이 선택한 루트에 맞는 OUT항공리스트를 가져오는 flight.xml의 select 명령을 실행한다
	public ArrayList<FlightVO>  selectOutFlightList(SqlSession mapper, FlightVO flightVO2){
		System.out.println("TripShoppingDAO클래스의 selectOutFlightList() 메소드 실행");
		return (ArrayList<FlightVO>) mapper.selectList("selectOutFlightList",flightVO2);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 IN/OUT항공(FlightVO)와 mapper를 넘겨 받고
	//customerFlight 테이블에 고객이 선택한 루트에 맞는 IN/OUT항공을 삽입하는 customerFlight.xml의 insert 명령을 실행한다
	public void insertCustomerFlight(SqlSession mapper,FlightVO vo) {
		System.out.println("TripShoppingDAO클래스의 insertCustomerFlight() 메소드 실행");
		mapper.insert("insertCustomerFlight",vo);
	}
	
	//TripShoppingService에서 호출되어 startNo와 endNo가 포함된 객체와 mapper를 넘겨 받고 
	//customerFlight 테이블에서 한 페이지 분량의 고객이 선택한 루트에 맞는 IN/OUT항공리스트를 얻어 오는 customerFlight.xml의 select 명령을 실행한다
	public ArrayList<FlightVO> selectCustomerFlight(HashMap<String, Integer> hmap,SqlSession mapper){
		System.out.println("TripShoppingDAO클래스의 selectCustomerFlight() 메소드 실행");
		return (ArrayList<FlightVO>) mapper.selectList("selectCustomerFlight",hmap);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 항공 상품의 idx와 mapper를 넘겨 받고
	//customerflight 테이블에서 고객이 선택한 항공 상품의 idx에 해당되는 항공 한 건을 얻어 오는 flight.xml의 select 명령을 실행한다
	public FlightVO selectFlightVO(SqlSession mapper,int idx) {
		System.out.println("TripShoppingDAO클래스의 selectFlightVO() 메소드 실행");
		return  (FlightVO) mapper.selectOne("selectFlightVO", idx);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 호텔을 얻어 오기 위한 조건을 묶은 hotelVo객체와 mapper를 넘겨 받고
	//hotel 테이블에서 고객이 선택한 루트에 맞는 호텔을 얻어 오기 위한 조건에 맞는 호텔 목록을 가져 오는 hotel.xml의 select 를 실행한다
	public ArrayList<HotelVO> selectHotelList(SqlSession mapper,HotelVO hotelVO){
		System.out.println("TripShoppingDAO클래스의 selectHotelList() 메소드 실행");
		return (ArrayList<HotelVO>) mapper.selectList("selectHotelList", hotelVO);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 호텔(hotelVO)와 mapper를 넘겨 받고
	//customerHotel 테이블에 고객이 선택한 루트에 맞는 호텔을 삽입하는 hotel.xml의 insert 명령을 실행한다
	public void insertCustomerHotel(SqlSession mapper,HotelVO vo) {
		System.out.println("TripShoppingDAO클래스의 insertCustomerHotel() 메소드 실행");
		mapper.insert("insertCustomerHotel", vo);
	}
	
	//TripShoppingService에서 호출되어 mapper를 넘겨 받고
	//customerHotel 테이블에서 전체 개수를 얻어 오는 hotel.xml의 select 명령을 실행한다
	public int selectTotalCount2(SqlSession mapper) {
		System.out.println("TripShoppingDAO클래스의 selectTotalCount2() 메소드 실행");
		return (int) mapper.selectOne("selectTotalCount2");
	}
	
	//TripShoppingService에서 호출되어 startNo와 endNo가 포함된 객체와 mapper를 넘겨 받고 
	//customerHotel 테이블에서 한 페이지 분량의 고객이 선택한 루트에 맞는 호텔리스트를 얻어 오는 hotel.xml의 select 명령을 실행한다
	public ArrayList<HotelVO> selectCustomerHotel(HashMap<String, Integer> hmap,SqlSession mapper){
		System.out.println("TripShoppingDAO클래스의 selectCustomerHotel() 메소드 실행");
		return (ArrayList<HotelVO>) mapper.selectList("selectCustomerHotel",hmap);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 호텔 상품의 idx와 mapper를 넘겨 받고
	//customerHotel 테이블에서 고객이 선택한 호텔 상품의 idx에 해당되는 호텔 한 건을 얻어 오는 hotel.xml의 select 명령을 실행한다
	public HotelVO selectHotelVO(int idx,SqlSession mapper) {
		System.out.println("TripShoppingDAO클래스의 selectHotelVO() 메소드 실행");
		return (HotelVO) mapper.selectOne("selectHotelVO", idx);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 교통을 얻어 오기 위한 조건을 묶은 trafficVo객체와 mapper를 넘겨 받고
	//traffic 테이블에서 고객이 선택한 루트에 맞는 교통을 얻어 오기 위한 조건에 맞는 교통 목록을 가져 오는 traffic.xml의 select 를 실행한다
	public ArrayList<TrafficVO> selectTrafficList(TrafficVO trafficVO,SqlSession mapper){
		System.out.println("TripShoppingDAO클래스의 selectTrafficList() 메소드 실행");
		return (ArrayList<TrafficVO>) mapper.selectList("selectTrafficList", trafficVO);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 교통(trafficVO)와 mapper를 넘겨 받고
	//customerTraffic 테이블에 고객이 선택한 루트에 맞는 교통을 삽입하는 traffic.xml의 insert 명령을 실행한다
	public void  insertCustomerTraffic(SqlSession mapper,TrafficVO vo) {
		System.out.println("TripShoppingDAO클래스의 insertCustomerTraffic() 메소드 실행");
		mapper.insert("insertCustomerTraffic", vo);
	}
	
	//TripShoppingService에서 호출되어 startNo와 endNo가 포함된 객체와 mapper를 넘겨 받고 
	//customerTraffic 테이블에서 한 페이지 분량의 고객이 선택한 루트에 맞는 교통리스트를 얻어 오는 traffic.xml의 select 명령을 실행한다
	public ArrayList<TrafficVO> selectCustomerTraffic(SqlSession mapper, HashMap<String, Integer> hmap){
		System.out.println("TripShoppingDAO클래스의 selectCustomerTraffic() 메소드 실행");
		return (ArrayList<TrafficVO>) mapper.selectList("selectCustomerTraffic",hmap);
	}
	
	//TripShoppingService에서 호출되어 mapper를 넘겨 받고
	//customerHotel 테이블에서 전체 개수를 얻어 오는 hotel.xml의 select 명령을 실행한다
	public int selectTotalCount3(SqlSession mapper) {
		System.out.println("TripShoppingDAO클래스의 selectTotalCount3() 메소드 실행");
		return (int) mapper.selectOne("selectTotalCount3");
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 ticket을 얻어 오기 위한 조건을 묶은 ticketVo객체와 mapper를 넘겨 받고
	//ticket 테이블에서 고객이 선택한 루트에 맞는 ticket을 얻어 오기 위한 조건에 맞는 ticket 목록을 가져 오는 ticket.xml의 select를 실행한다
	public ArrayList<TicketVO> selectTicketList(TicketVO ticketVO, SqlSession mapper){
		System.out.println("TripShoppingDAO클래스의 selectTicketList() 메소드 실행");
		return (ArrayList<TicketVO>) mapper.selectList("selectTicketList", ticketVO);
	}
	
	//TripShoppingService에서 호출되어 고객이 선택한 루트에 맞는 ticket(ticketVO)와 mapper를 넘겨 받고
	//customerTicket 테이블에 고객이 선택한 루트에 맞는 ticket을 삽입하는 ticket.xml의 insert 명령을 실행한다
	public void insertCustomerTicket(SqlSession mapper,TicketVO vo) {
		System.out.println("TripShoppingDAO클래스의 insertCustomerTicket() 메소드 실행");
		mapper.insert("insertCustomerTicket", vo);
	}
	
	//TripShoppingService에서 호출되어 mapper를 넘겨 받고
	//customerTicket 테이블에서 전체 개수를 얻어 오는 ticket.xml의 select 명령을 실행한다
	public int selectTotalCount4(SqlSession mapper) {
		System.out.println("TripShoppingDAO클래스의 selectTotalCount4() 메소드 실행");
		return (int) mapper.selectOne("selectTotalCount4");
	}
	
	//TripShoppingService에서 호출되어 startNo와 endNo가 포함된 객체와 mapper를 넘겨 받고 
	//customerTicket 테이블에서 한 페이지 분량의 고객이 선택한 루트에 맞는 ticket리스트를 얻어 오는 ticket.xml의 select 명령을 실행한다
	public ArrayList<TicketVO> selectCustomerTicket(SqlSession mapper,HashMap<String, Integer> hmap){
		return (ArrayList<TicketVO>) mapper.selectList("selectCustomerTicket",hmap);
	}
}
