package kr.koreait.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.dao.TripShoppingDAO;
import kr.koreait.mybatis.MySession;
import kr.koreait.vo.CustomerList;
import kr.koreait.vo.CustomerVO;
import kr.koreait.vo.FlightList;
import kr.koreait.vo.FlightVO;
import kr.koreait.vo.HotelList;
import kr.koreait.vo.HotelVO;
import kr.koreait.vo.NationalityCategoryList;
import kr.koreait.vo.NationalityCategoryVO;
import kr.koreait.vo.RouteList;
import kr.koreait.vo.RouteVO;
import kr.koreait.vo.TicketList;
import kr.koreait.vo.TicketVO;
import kr.koreait.vo.TrafficList;
import kr.koreait.vo.TrafficVO;

public class TripShoppingService {
	private static TripShoppingService instance=new TripShoppingService();
	private TripShoppingService() {}
	public static TripShoppingService getInstance() {return instance;}
	
	//signUpOK.jsp에서 호출되어 회원가입 정보를 넘겨 받고 mapper를 얻어 오고
	//customer 테이블에 회원정보를 insert하는 메소드를 호출하는 메소드
	public void signUp(CustomerVO vo) {
		System.out.println("TripShoppingService의 signUp() 메소드");
		SqlSession mapper=MySession.getSession();
		TripShoppingDAO.getInstance().signUp(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//loginOK.jsp에서 호출되어 로그인 정보를 넘겨 받고 mapper를 얻어 오고
	//customer테이블에서 해당회원 정보를 select하는 메소드를 호출하는 메소드
	public CustomerVO checkCustomer(CustomerVO vo) {
		System.out.println("TripShoppingService의 checkCustomer() 실행");
		SqlSession mapper=MySession.getSession();
		CustomerVO customerVO=TripShoppingDAO.getInstance().checkCustomer(mapper, vo);
		mapper.close();
		return customerVO;
	}
	
	//idCheck.jsp에서 호출되어 mapper를 얻어 오고
	//customer 테이블에서 모든 회원의 id를 select하는 메소드를 호출하는 메소드
	public ArrayList<String> selectIdList(){
		System.out.println("TripShoppingService의 selectidList() 실행");
		SqlSession mapper=MySession.getSession();
		ArrayList<String> idList=new ArrayList<>();
		idList=TripShoppingDAO.getInstance().selectIdList(mapper);
		mapper.close();
		return idList;
	}
	
	//continentInsert.jsp에서 호츨되어 테이블에 저장할 메인 카테고리(continent)가 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//nationalityCatgory 테이블에 메인카테고리(continent)를 insert하는 메소드를 호출하는 메소드
	public void continentInsert(NationalityCategoryVO vo) {
		System.out.println("TripShoppingService의 continentInsert() 실행");
		SqlSession mapper=MySession.getSession();
		TripShoppingDAO.getInstance().continentInsert(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//travelDestinationInsert.jsp에서 호출되어 테이블에 저장할 서브 카테고리의 부모 카테고리의 정보가 담긴 객체를 넘겨 받고
	//mapper를 얻어 오고 sql 실행전 전처리를 하고 nationalityCatgory 테이블에 서브카테고리(travelDestination)를 insert하는 메소드를 호출하는 메소드
	public void travelDestinationInsert(NationalityCategoryVO vo) {
		System.out.println("TripShoppingService의 travelDestinationInsert() 실행");
		SqlSession mapper=MySession.getSession();
		
		//서브카테고리의 위치를 결정하기 위해 lev과 seq를 1씩 증가 
		vo.setLev(vo.getLev()+1);//서브카테고리의 레벨을 부모 카테고리보다 1증가시킨다
		vo.setSeq(vo.getSeq()+1);//서브카테고리가 부모카테고리 바로 아래에 나와야 하므로 출력순서를 1증가시킨다
		
		//서브 카테고리를 위치에 맞게 삽입하기 위해 같은 카테고리 그룹(ref)의 카테고리 출력순서(seq)를 조정한다
		//새로 삽입된 서브 카테고리가 부모 카테고리 바로 아래에 나오고 나머지는 다 1씩 밀린다
		HashMap<String, Integer> hmap=new HashMap<>();
		hmap.put("ref", vo.getRef());
		hmap.put("seq", vo.getSeq());
		//카테고리의 출력순서를 조장하는 메소드를 실행
		TripShoppingDAO.getInstance().increment(mapper, hmap);
		
		//서브카테고리를 삽입하는 메소드를 실행
		TripShoppingDAO.getInstance().travelDestinationInsert(mapper, vo);
		
		mapper.commit();
		mapper.close();
	}
	
	//nationalityCategoryList.jsp에서 호출되어 mapper를 얻어 오고
	//테이블에 저장된 전체 카테고리를 select하는 메소드를 호출하는 메소드
	public NationalityCategoryList selectNationalityCategoryList() {
		System.out.println("TripShoppingService의 selectNationalityCategoryList() 실행");
		SqlSession mapper=MySession.getSession();
		//카테고리 목록을 저장할 객체 선언
		NationalityCategoryList nationalityCategoryList=new NationalityCategoryList();
		//테이블에서 얻어 온 카테고리 목록을 NationalityCategoryList 클래스의 ArrayList에 저장
		nationalityCategoryList.setNationalityCategoryList(TripShoppingDAO.getInstance().selectNationalityCategoryList(mapper));
		mapper.close();
		return nationalityCategoryList;		
	}
	
	//nationalityCategoryList.jsp에서 호출되어 mapper를 얻어 오고 continent를 넘겨 받고
	//continent에 따른 카테고리 목록을 select하는 메소드를 호출하는 메소드
	public NationalityCategoryList selectNationalityCategoryList2(String continent) {
		System.out.println("TripShoppingService의 selectNationalityCategoryList2() 실행");
		SqlSession mapper=MySession.getSession();
		//continent부류에 있는 카테고리 목록을 얻어 오기 위해서는(continent에 따른 카테고리 목록을 얻어 오기 위해서)
		//name이 continent인 카테고리의 ref와 일치하는 카테고리들을 얻기 위해 name이 continent인 카테고리의 ref를 가져 온다
		int continentRef=0;
		try {
		continentRef=TripShoppingDAO.getInstance().selectContinentRef(mapper, continent);
		}catch(Exception e) {}
		//System.out.println(continentRef);
		//카테고리 목록을 저장할 객체 선언
		NationalityCategoryList nationalityCategoryList2=new NationalityCategoryList();
		//테이블에서 얻어 온 카테고리 목록을 NationalityCategoryList 클래스의 ArrayList에 저장
		nationalityCategoryList2.setNationalityCategoryList(TripShoppingDAO.getInstance().selectNationalityCategoryList2(mapper, continentRef));
		mapper.close();
		return nationalityCategoryList2;
	}
	
	//routeInsert.jsp에서 호출되어 routeVO를 넘겨 받고 mapper를 얻어 오고
	//route테이블에 루트 한 건을 insert하는 메소드를 호출하는 메소드
	public void routeInsert(RouteVO vo) {
		System.out.println("TripShoppingService의 routeInsert() 실행");
		SqlSession mapper=MySession.getSession();
		TripShoppingDAO.getInstance().routeInsert(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//routeList.jsp에서 호출되어 mapper를 얻어 오고
	//route 테이블에서 전체 루트리스트를 얻어 오는 메소드를 호출하는 메소드
	public RouteList selectRouteList() {
		System.out.println("TripShoppingService의 selectRouteList() 실행");
		SqlSession mapper=MySession.getSession();
		RouteList routeList=new RouteList();
		routeList.setRouteList(TripShoppingDAO.getInstance().selectRouteList(mapper));
		mapper.close();
		return routeList;
	}
	
	//flightList.jsp에서 호출되어 고객이 선택한 루트에 맞는 IN항공권을 얻기 위한 조건들을 묶은 flightVO를 넘겨 받고 mapper를 얻어 오고
	//flight 테이블에서 고객이 선택한 루트에 맞는 IN항공라스트를 얻어 오는 메소드를 호출하는 메소드
	public FlightList selectInFlightList(FlightVO flightVO) {
		System.out.println("TripShoppingService의 selectInFlightList() 실행");
		SqlSession mapper=MySession.getSession();
		FlightList inFlightList=new FlightList();
		inFlightList.setFlightList(TripShoppingDAO.getInstance().selectInFlightList(mapper, flightVO));
		mapper.close();
		return inFlightList;
	}
	
	//flightList.jsp에서 호출되어 고객이 선택한 루트에 맞는 OUT항공권을 얻기 위한 조건들을 묶은 flightVO2를 넘겨 받고 mapper를 얻어 오고
    //flight 테이블에서 고객이 선택한 루트에 맞는 OUT항공리스트를 얻어 오는 메소드를 호출하는 메소드
	public FlightList selectOutFlightList(FlightVO flightVO2) {
		System.out.println("TripShoppingService의 selectOutFlightList() 실행");
		SqlSession mapper=MySession.getSession();
		FlightList outFlightList=new FlightList();
		outFlightList.setFlightList(TripShoppingDAO.getInstance().selectOutFlightList(mapper, flightVO2));
		mapper.close();
		return outFlightList;
	}
	
	//flightList.jsp에서 호출되어 고객이 선택한 루트에 맞는 IN/OUT항공(FlightVO)를 넘겨 받고 mapper를 얻어 오고
	//customerFlight 테이블에 고객이 선택한 루트에 맞는 IN/OUT항공을 삽입하는 메소드를 호출하는 메소드
	public void insertCustomerFlight(FlightVO vo) {
		System.out.println("TripShoppingService의 insertCustomerFlight() 실행");
		SqlSession mapper=MySession.getSession();
		TripShoppingDAO.getInstance().insertCustomerFlight(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//flightList.jsp에서 호출되어 currentPage를 넘겨 받고 mapper를 얻어 오고
	//고객이 선택한 루트에 맞는 in/out항공을 customerFlight 테이블에서 한 페이지 분량을 얻어 오는 메소드를 호출하는 메소드
	public FlightList selectCustomerFlight(int currentPage) {
		System.out.println("TripShoppingService의 selectCustomerFlight() 실행");
		SqlSession mapper=MySession.getSession();
		FlightList customerFlightList=null;
		
		int pageSize=10;
		int totalCount=TripShoppingDAO.getInstance().selectTotalCount(mapper);
		customerFlightList=new FlightList(pageSize, totalCount, currentPage);
		
		HashMap<String, Integer> hmap=new HashMap<>();
		hmap.put("startNo", customerFlightList.getStartNo());
		hmap.put("endNo", customerFlightList.getEndNo());
		
		customerFlightList.setFlightList(TripShoppingDAO.getInstance().selectCustomerFlight(hmap, mapper));
		mapper.close();
		return customerFlightList;
	}
	
	//hotelList.jsp에서 호출되어 고객이 선택한 항공 상품의 idx를 넘겨 받고 mapper를 얻어 오고
	//고객이 선택한 항공 상품의 idx에 해당되는 항공 한 건을 얻어 오는 메소드를 호출하는 매소드
	public FlightVO selectFlightVO(int idx) {
		System.out.println("TripShoppingService의 selectFlightVO() 실행");
		SqlSession mapper=MySession.getSession();
		FlightVO flightVO=TripShoppingDAO.getInstance().selectFlightVO(mapper, idx);
		mapper.close();
		return  flightVO;
	}

	//hotelList.jsp에서 호출되어 고객이 선택한 루트에 맞는 호텔을 얻어 오기 위한 조건을 묶은 hotelVo객체를 넘겨 받고
	//mapper를 얻어 오고 hotel 테이블에서 고객이 선택한 루트에 맞는 호텔을 얻어 오기 위한 조건에 맞는 호텔 목록을 얻어 오는 메소드를 호출하는 메소드
	public HotelList selectHotelList(HotelVO hotelVO) {
		System.out.println("TripShoppingService의 selectHotelList() 실행");
		SqlSession mapper=MySession.getSession();
		HotelList hotelList =new HotelList();
		hotelList.setHotelList(TripShoppingDAO.getInstance().selectHotelList(mapper, hotelVO));
		mapper.close();
		return hotelList;
	}
	
	//hotelList.jsp에서 호출되어 고객이 선택한 루트에 맞는 호텔(hotelVO)를 넘겨 받고 mapper를 얻어 오고
	//customerHotel에 고객이 선택한 루트에 맞는 호텔을 삽입하는 메소드를 호출하는 메소드
	public void insertCustomerHotel(HotelVO vo) {
		System.out.println("TripShoppingService의 selectHotelList() 실행");
		SqlSession mapper=MySession.getSession();
		TripShoppingDAO.getInstance().insertCustomerHotel(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//hotelList.jsp에서 호출되어 currentPage를 넘겨 받고 mapper를 얻어 오고
	//고객이 선택한 루트에 맞는 호텔을 customerHotel 테이블에서 한 페이지 분량을 얻어 오는 메소드를 호출하는 메소드
	public HotelList selectCustomerHotel(int currentPage) {
		System.out.println("TripShoppingService의 selectCustomerHotelt() 실행");
		SqlSession mapper=MySession.getSession();
		HotelList customerHotelList = null;
		
		int pageSize=10;
		int totalCount=TripShoppingDAO.getInstance().selectTotalCount2(mapper);
		customerHotelList=new HotelList(pageSize, totalCount, currentPage);
		
		HashMap<String, Integer> hmap=new HashMap<>();
		hmap.put("startNo", customerHotelList.getStartNo());
		hmap.put("endNo", customerHotelList.getEndNo());
		
		customerHotelList.setHotelList(TripShoppingDAO.getInstance().selectCustomerHotel(hmap, mapper));
		mapper.close();
		return customerHotelList;
	}
	
	//trafficList.jsp에서 호출되어 고객이 선택한 호텔 상품의 idx를 넘겨 받고 mapper를 얻어 오고
    //고객이 선택한 호텔 상품의 idx에 해당되는 호텔 한 건을 얻어 오는 메소드를 호출하는 매소드
	public HotelVO selectHotelVO(int idx) {
		System.out.println("TripShoppingService의 selectHotelVO() 실행");
		SqlSession mapper=MySession.getSession();
		HotelVO hotelVO=TripShoppingDAO.getInstance().selectHotelVO(idx, mapper);
		mapper.close();
		return hotelVO;
	}
	
	//trafficList.jsp에서 호출되어 고객이 선택한 루트에 맞는 교통을 얻어 오기 위한 조건을 묶은 trafficVo객체를 넘겨 받고
	//mapper를 얻어 오고 traffic 테이블에서 고객이 선택한 루트에 맞는 교통을 얻어 오기 위한 조건에 맞는 교통 목록을 얻어 오는 메소드를 호출하는 메소드
	public TrafficList selectTrafficList(TrafficVO trafficVO) {
		System.out.println("TripShoppingService의 selectTrafficList() 실행");
		SqlSession mapper=MySession.getSession();
		TrafficList trafficList=new TrafficList();
		trafficList.setTrafficList(TripShoppingDAO.getInstance().selectTrafficList(trafficVO, mapper));
		mapper.close();
		return trafficList;
	}
	
	//trafficList.jsp에서 호출되어 고객이 선택한 루트에 맞는 교통(trafficVO)를 넘겨 받고 mapper를 얻어 오고
	//customerTraffic에 고객이 선택한 루트에 맞는 교통을 삽입하는 메소드를 호출하는 메소드
	public void insertCustomerTraffic(TrafficVO vo) {
		System.out.println("TripShoppingService의 insertCustomerTraffic() 실행");
		SqlSession mapper=MySession.getSession();
		TripShoppingDAO.getInstance().insertCustomerTraffic(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//trafficList.jsp에서 호출되어 currentPage를 넘겨 받고 mapper를 얻어 오고
    //고객이 선택한 루트에 맞는 교통을 customerTraffic 테이블에서 한 페이지 분량을 얻어 오는 메소드를 호출하는 메소드
	public TrafficList selectCustomerTraffic(int currentPage) {
		System.out.println("TripShoppingService의 selectCustomerTraffic() 실행");
		SqlSession mapper=MySession.getSession();
		TrafficList customerTrafficList=null;
		
		int pageSize=10;
		int totalCount=TripShoppingDAO.getInstance().selectTotalCount3(mapper);
		customerTrafficList=new TrafficList(pageSize, totalCount, currentPage);
		
		HashMap<String, Integer> hmap=new HashMap<>();
		hmap.put("startNo", customerTrafficList.getStartNo());
		hmap.put("endNo", customerTrafficList.getEndNo());
		
		customerTrafficList.setTrafficList(TripShoppingDAO.getInstance().selectCustomerTraffic(mapper, hmap));
		mapper.close();
		return customerTrafficList;	
	}
	
	//ticketList.jsp에서 호출되어 고객이 선택한 루트에 맞는 티켓을 얻어 오기 위한 조건을 묶은 ticketVo객체를 넘겨 받고
	//mapper를 얻어 오고 ticket 테이블에서 고객이 선택한 루트에 맞는 티켓을 얻어 오기 위한 조건에 맞는 티켓 목록을 얻어 오는 메소드를 호출하는 메소드
	public TicketList selectTicketList(TicketVO ticketVO) {
		System.out.println("TripShoppingService의 selectTicketList() 실행");
		SqlSession mapper=MySession.getSession();
		TicketList ticketList=new TicketList();
		ticketList.setTicketList(TripShoppingDAO.getInstance().selectTicketList(ticketVO, mapper));
		mapper.close();
		return ticketList;
	}
	
	//ticketList.jsp에서 호출되어 고객이 선택한 루트에 맞는 ticket(ticketVO)를 넘겨 받고 mapper를 얻어 오고
	//customerTicket에 고객이 선택한 루트에 맞는 ticket을 삽입하는 메소드를 호출하는 메소드
	public void insertCustomerTicket(TicketVO vo) {
		System.out.println("TripShoppingService의 insertCustomerTicket() 실행");
		SqlSession mapper=MySession.getSession();
		TripShoppingDAO.getInstance().insertCustomerTicket(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//ticketList.jsp에서 호출되어 currentPage를 넘겨 받고 mapper를 얻어 오고
    //고객이 선택한 루트에 맞는 ticket을 customerticket 테이블에서 한 페이지 분량을 얻어 오는 메소드를 호출하는 메소드
	public TicketList selectCustomerTicket(int currentPage) {
		System.out.println("TripShoppingService의 selectCustomerTicket() 실행");
		SqlSession mapper=MySession.getSession();
		TicketList customerTicketList=null;
		
		int pageSize=10;
		int totalCount=TripShoppingDAO.getInstance().selectTotalCount4(mapper);
		customerTicketList=new TicketList(pageSize, totalCount, currentPage);
		
		HashMap<String, Integer> hmap=new HashMap<>();
		hmap.put("startNo", customerTicketList.getStartNo());
		hmap.put("endNo", customerTicketList.getEndNo());
		
		customerTicketList.setTicketList(TripShoppingDAO.getInstance().selectCustomerTicket(mapper, hmap));
		mapper.close();
		return customerTicketList;
	}
}
