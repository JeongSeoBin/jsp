package kr.koreait.vo;

public class RouteVO {
	private int routeSeq;
	private String city;
	private String inout;
	private int totalDay;
	
	public int getRouteSeq() {
		return routeSeq;
	}
	public void setRouteSeq(int routeSeq) {
		this.routeSeq = routeSeq;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getInout() {
		return inout;
	}
	public void setInout(String inout) {
		this.inout = inout;
	}
	public int getTotalDay() {
		return totalDay;
	}
	public void setTotalDay(int totalDay) {
		this.totalDay = totalDay;
	}
	
	@Override
	public String toString() {
		return "RouteVO [routeSeq=" + routeSeq + ", city=" + city + ", inout=" + inout + ", totalDay=" + totalDay + "]";
	}
}
