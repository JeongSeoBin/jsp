package kr.koreait.vo;

import java.util.Date;

public class HotelVO {
	private int idx;
	private String city;
	private int checkInYear;
	private int checkInMonth;
	private int checkInDate;
	private int checkOutYear;
	private int checkOutMonth;
	private int checkOutDate;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getCheckInYear() {
		return checkInYear;
	}
	public void setCheckInYear(int checkInYear) {
		this.checkInYear = checkInYear;
	}
	public int getCheckInMonth() {
		return checkInMonth;
	}
	public void setCheckInMonth(int checkInMonth) {
		this.checkInMonth = checkInMonth;
	}
	public int getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(int checkInDate) {
		this.checkInDate = checkInDate;
	}
	public int getCheckOutYear() {
		return checkOutYear;
	}
	public void setCheckOutYear(int checkOutYear) {
		this.checkOutYear = checkOutYear;
	}
	public int getCheckOutMonth() {
		return checkOutMonth;
	}
	public void setCheckOutMonth(int checkOutMonth) {
		this.checkOutMonth = checkOutMonth;
	}
	public int getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(int checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	
	@Override
	public String toString() {
		return "HotelVO [idx=" + idx + ", city=" + city + ", checkInYear=" + checkInYear + ", checkInMonth="
				+ checkInMonth + ", checkInDate=" + checkInDate + ", checkOutYear=" + checkOutYear + ", checkOutMonth="
				+ checkOutMonth + ", checkOutDate=" + checkOutDate + "]";
	}
}
