package kr.koreait.vo;

import java.util.Date;

public class TicketVO {
	private int idx;
	private String city;
	private int entranceYear;
	private int entranceMonth;
	private int entranceDate;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getEntranceYear() {
		return entranceYear;
	}
	public void setEntranceYear(int entranceYear) {
		this.entranceYear = entranceYear;
	}
	public int getEntranceMonth() {
		return entranceMonth;
	}
	public void setEntranceMonth(int entranceMonth) {
		this.entranceMonth = entranceMonth;
	}
	public int getEntranceDate() {
		return entranceDate;
	}
	public void setEntranceDate(int entranceDate) {
		this.entranceDate = entranceDate;
	}
	
	@Override
	public String toString() {
		return "TicketVO [idx=" + idx + ", city=" + city + ", entranceYear=" + entranceYear + ", entranceMonth="
				+ entranceMonth + ", entranceDate=" + entranceDate + "]";
	}
}
