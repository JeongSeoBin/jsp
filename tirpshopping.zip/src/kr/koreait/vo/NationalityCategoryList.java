package kr.koreait.vo;

import java.util.ArrayList;

public class NationalityCategoryList {
	private ArrayList<NationalityCategoryVO> nationalityCategoryList=new ArrayList<NationalityCategoryVO>();

	public ArrayList<NationalityCategoryVO> getNationalityCategoryList() {
		return nationalityCategoryList;
	}

	public void setNationalityCategoryList(ArrayList<NationalityCategoryVO> nationalityCategoryList) {
		this.nationalityCategoryList = nationalityCategoryList;
	}

	@Override
	public String toString() {
		return "NationalityCategoryList [nationalityCategoryList=" + nationalityCategoryList + "]";
	}
}
