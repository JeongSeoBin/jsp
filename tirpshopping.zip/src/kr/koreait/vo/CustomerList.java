package kr.koreait.vo;

import java.util.ArrayList;

public class CustomerList {
	ArrayList<CustomerVO> customerList=new ArrayList<>();

	public ArrayList<CustomerVO> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(ArrayList<CustomerVO> customerList) {
		this.customerList = customerList;
	}
}
