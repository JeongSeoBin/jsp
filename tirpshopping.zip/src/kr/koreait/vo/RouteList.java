package kr.koreait.vo;

import java.util.ArrayList;

public class RouteList {
	private ArrayList<RouteVO> routeList=new ArrayList<>();

	public ArrayList<RouteVO> getRouteList() {
		return routeList;
	}

	public void setRouteList(ArrayList<RouteVO> routeList) {
		this.routeList = routeList;
	}

	@Override
	public String toString() {
		return "RouteList [routeList=" + routeList + "]";
	}
}
