package kr.koreait.vo;

public class TrafficVO {
	private int idx;
	private String startingPoint;
	private String destination;
	private int departureYear;
	private int departureMonth;
	private int departureDate;
	private int arriveYear;
	private int arriveMonth;
	private int arriveDate;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getStartingPoint() {
		return startingPoint;
	}
	public void setStartingPoint(String startingPoint) {
		this.startingPoint = startingPoint;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getDepartureYear() {
		return departureYear;
	}
	public void setDepartureYear(int departureYear) {
		this.departureYear = departureYear;
	}
	public int getDepartureMonth() {
		return departureMonth;
	}
	public void setDepartureMonth(int departureMonth) {
		this.departureMonth = departureMonth;
	}
	public int getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(int departureDate) {
		this.departureDate = departureDate;
	}
	public int getArriveYear() {
		return arriveYear;
	}
	public void setArriveYear(int arriveYear) {
		this.arriveYear = arriveYear;
	}
	public int getArriveMonth() {
		return arriveMonth;
	}
	public void setArriveMonth(int arriveMonth) {
		this.arriveMonth = arriveMonth;
	}
	public int getArriveDate() {
		return arriveDate;
	}
	public void setArriveDate(int arriveDate) {
		this.arriveDate = arriveDate;
	}
	
	@Override
	public String toString() {
		return "TrafficVO [idx=" + idx + ", startingPoint=" + startingPoint + ", destination=" + destination
				+ ", departureYear=" + departureYear + ", departureMonth=" + departureMonth + ", departureDate="
				+ departureDate + ", arriveYear=" + arriveYear + ", arriveMonth=" + arriveMonth + ", arriveDate="
				+ arriveDate + "]";
	}	
}