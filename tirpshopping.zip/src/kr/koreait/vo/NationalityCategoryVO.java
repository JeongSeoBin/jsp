package kr.koreait.vo;

public class NationalityCategoryVO {
	private String name;
	private int idx;
	private int ref;
	private int seq;
	private int lev;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getRef() {
		return ref;
	}
	public void setRef(int ref) {
		this.ref = ref;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public int getLev() {
		return lev;
	}
	public void setLev(int lev) {
		this.lev = lev;
	}
	
	@Override
	public String toString() {
		return "NationalityCategoryVO [name=" + name + ", idx=" + idx + ", ref=" + ref + ", seq=" + seq + ", lev=" + lev
				+ "]";
	}
}
