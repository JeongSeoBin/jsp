package kr.koreait.vo;

public class CustomerVO {
	private int idx;
	private String name;
	private String id;
	private String password;
	private String nationality;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	
	@Override
	public String toString() {
		return "CustomerVO [idx=" + idx + ", name=" + name + ", id=" + id + ", password=" + password + ", nationality="
				+ nationality + "]";
	}
}
