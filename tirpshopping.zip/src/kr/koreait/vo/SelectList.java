package kr.koreait.vo;

import java.util.ArrayList;

public class SelectList {
	//사용자가 select한 상품들의 idx가 저장된 ArrayList이다
	private ArrayList<Integer> selectedFlightList=new ArrayList<>();
	private ArrayList<Integer> selectedHotelList=new ArrayList<>();
	private ArrayList<Integer> selectedTrafficList=new ArrayList<>();
	private ArrayList<Integer> selectedTicketList=new ArrayList<>();
	
	public ArrayList<Integer> getSelectedFlightList() {
		return selectedFlightList;
	}
	public void setSelectedFlightList(ArrayList<Integer> selectedFlightList) {
		this.selectedFlightList = selectedFlightList;
	}
	public ArrayList<Integer> getSelectedHotelList() {
		return selectedHotelList;
	}
	public void setSelectedHotelList(ArrayList<Integer> selectedHotelList) {
		this.selectedHotelList = selectedHotelList;
	}
	public ArrayList<Integer> getSelectedTrafficList() {
		return selectedTrafficList;
	}
	public void setSelectedTrafficList(ArrayList<Integer> selectedTrafficList) {
		this.selectedTrafficList = selectedTrafficList;
	}
	public ArrayList<Integer> getSelectedTicketList() {
		return selectedTicketList;
	}
	public void setSelectedTicketList(ArrayList<Integer> selectedTicketList) {
		this.selectedTicketList = selectedTicketList;
	}
	
	@Override
	public String toString() {
		return "SelectList [selectedFlightList=" + selectedFlightList + ", selectedHotelList=" + selectedHotelList
				+ ", selectedTrafficList=" + selectedTrafficList + ", selectedTicketList=" + selectedTicketList + "]";
	}
}
