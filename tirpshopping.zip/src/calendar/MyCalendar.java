package calendar;

public class MyCalendar {
	//윤년/평년 판별 메소드
	//년도를 넘겨 받아 윤년/평년을 판단해 윤년이면 true, 평년이면 false를 리턴하는 메서드
	public static boolean isLeapYear(int year){
		//년도가 4로 나눠 떨어지고 100으로 나눠 떨어지지 않거나 400으로 나눠 떨어지면 윤년,그렇지 않으면 평년
		return year%4==0 && year%100!=0 || year%400==0;
	}
	
	//년,월을 넘겨 받아 그 달의 마지막 날짜를 리턴하는 메소드
	public static int lastDay(int year,int month) {
		//각 달의 마지막 날짜를 기억하는 배열을 만든다
		int [] m= {31,28,31,30,31,30,31,31,30,31,30,31};
		//2월의 마지막날짜를 결정(평년이면 28 윤년이면 29)
		m[1]=isLeapYear(year)?29:28;
		//마지막 날짜를 리턴
		return m[month-1];
	}

}
